package cn.wadian.app;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.*;

public final class MainActivity extends Activity {
    private final int BG=Color.rgb(13,23,33), PANEL=Color.rgb(25,40,53), WHITE=Color.rgb(240,245,248), MUTED=Color.rgb(157,178,193), ACCENT=Color.rgb(153,219,240);
    private LinearLayout body;
    private TextView loginStatus;
    private android.content.SharedPreferences prefs;
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private Future<?> activeLogin;
    private byte[] qrBytes, saveBytes;
    private int page=0;
    private boolean busy=false;
    private String transientStatus="";
    private int accountGeneration=0;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=ShopJob.prefs(this); Alerts.setup(this);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        if(Build.VERSION.SDK_INT>=35) getWindow().getDecorView().setOnApplyWindowInsetsListener((v,insets)-> {
            android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());
            v.setPadding(bars.left,bars.top,bars.right,bars.bottom); return insets;
        });
        if(prefs.getBoolean("enabled",false)) ShopJob.schedule(this);
        render();
    }
    private int dp(int value) { return (int)(value*getResources().getDisplayMetrics().density+.5f); }
    private GradientDrawable shape(int color,int radius) { GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private TextView label(String text,int size,int color) {
        TextView t=new TextView(this); t.setText(text); t.setTextColor(color); t.setTextSize(size); t.setLineSpacing(dp(4),1); return t;
    }
    private LinearLayout column() { LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); return box; }
    private void gap(LinearLayout box,int height) { View v=new View(this); box.addView(v,new LinearLayout.LayoutParams(1,dp(height))); }
    private TextView button(LinearLayout parent,String title,boolean strong,Runnable action) {
        TextView b=label(title,15,strong?BG:WHITE); b.setGravity(Gravity.CENTER); b.setTypeface(null,Typeface.BOLD);
        b.setPadding(dp(12),dp(15),dp(12),dp(15)); b.setBackground(shape(strong?ACCENT:PANEL,14));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.topMargin=dp(10); parent.addView(b,lp);
        b.setOnClickListener(v->action.run()); return b;
    }
    private LinearLayout card(LinearLayout parent) {
        LinearLayout box=column(); box.setPadding(dp(20),dp(20),dp(20),dp(20)); box.setBackground(shape(PANEL,20));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.topMargin=dp(14); parent.addView(box,lp); return box;
    }
    private JSONObject session() {
        try { synchronized(ShopJob.LOCK) { return new Vault(this).load(); } }
        catch(Exception e) { transientStatus="本机登录信息无法解密，请重新登录"; return null; }
    }
    private void render() {
        LinearLayout root=column(); root.setBackgroundColor(BG); root.setPadding(dp(22),dp(18),dp(22),dp(8));
        LinearLayout brand=new LinearLayout(this); brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView image=new ImageView(this); image.setImageResource(R.drawable.samoyed); image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setBackground(shape(PANEL,16)); image.setClipToOutline(true); brand.addView(image,new LinearLayout.LayoutParams(dp(52),dp(52)));
        LinearLayout words=column(); words.setPadding(dp(14),0,0,0); words.addView(label("萨摩耶开商店",23,WHITE)); words.addView(label("商店刷新，萨摩耶来报信",12,MUTED)); brand.addView(words); root.addView(brand);
        gap(root,20);
        LinearLayout tabs=new LinearLayout(this);
        String[] titles={"今日商店","账号登录","提醒设置"};
        for(int i=0;i<titles.length;i++) { final int index=i; TextView t=label(titles[i],14,page==i?BG:MUTED); t.setGravity(Gravity.CENTER); t.setPadding(0,dp(12),0,dp(12)); if(page==i) t.setBackground(shape(ACCENT,12)); tabs.addView(t,new LinearLayout.LayoutParams(0,-2,1)); t.setOnClickListener(v->{page=index; render();}); }
        root.addView(tabs);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); body=column(); body.setPadding(0,dp(14),0,dp(20)); scroll.addView(body); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        TextView footer=label("独立个人工具 · 非腾讯官方应用",11,MUTED); footer.setGravity(Gravity.CENTER); root.addView(footer); setContentView(root);
        if(page==0) shopPage(); else if(page==1) loginPage(); else settingsPage();
    }
    private void shopPage() {
        body.addView(label("今天，刷到心动了吗？",27,WHITE)); gap(body,6);
        body.addView(label("不用翻牌。四款皮肤，直接看。",14,MUTED));
        JSONObject account=session();
        String date=prefs.getLong("cacheAt",0)==0?"尚未查询":Instant.ofEpochMilli(prefs.getLong("cacheAt",0)).atZone(StoreClock.zone()).format(DateTimeFormatter.ofPattern("MM-dd HH:mm"));
        LinearLayout summary=card(body); summary.addView(label(account==null?"先登录你的游戏账号":"已连接 · "+(account.optString("mode").equals("qq")?"QQ":"微信"),17,WHITE));
        summary.addView(label("上次查询："+date+"（手机时间）",12,MUTED));
        JSONArray items=new JSONArray(); try { items=new JSONArray(prefs.getString("cache","[]")); } catch(JSONException ignored) {}
        if(items.length()==0) {
            LinearLayout empty=card(body); empty.addView(label("商店还没开门",21,WHITE)); gap(empty,8);
            empty.addView(label("登录后点击下方查询。定时提醒开启后，每天会把四款皮肤送到通知栏。",14,MUTED));
        } else {
            for(int i=0;i<items.length();i++) {
                JSONObject item=items.optJSONObject(i); if(item==null) continue;
                LinearLayout tile=card(body); tile.addView(label(String.format(java.util.Locale.ROOT,"%02d  /  DAILY STORE",i+1),11,ACCENT)); gap(tile,12);
                tile.addView(label(item.optString("goods_name"),21,WHITE)); gap(tile,8);
                String line=ShopText.line(item); tile.addView(label(line.contains("    ")?line.substring(line.lastIndexOf("    ")+4):"价格待确认",17,ACCENT));
            }
            body.addView(label("以上为上次查询结果；离线时不会冒充今日实时数据。",12,MUTED));
        }
        button(body,account==null?"登录 QQ / 微信":busy?"正在执行…":"立即执行并弹窗",true,()-> {
            if(account==null) { page=1; render(); } else refresh();
        });
        gap(body,12); body.addView(label(transientStatus.isEmpty()?prefs.getString("status","登录成功后，即可设置每天自动提醒。"):transientStatus,13,MUTED));
    }
    private void refresh() { refresh(true); }
    private void refresh(boolean notify) {
        if(notify && !Alerts.allowed(this)) {
            if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},21);
            else openNotifications();
            toast("请先允许通知，再点击立即执行"); return;
        }
        if(busy) return; busy=true; transientStatus="正在连接商店…"; final int generation=accountGeneration; render();
        io.execute(()-> {
            try {
                JSONObject account=session(); JSONArray list=ShopApi.fetch(account);
                runOnUiThread(()-> {
                    if(generation!=accountGeneration) return;
                    prefs.edit().putString("cache",list.toString()).putLong("cacheAt",System.currentTimeMillis()).apply();
                    transientStatus="查询成功，共 "+list.length()+" 款皮肤";
                    if(notify) {
                        try {
                            if(list.length()!=4) transientStatus="返回数量异常，未弹出每日商店通知，请在官方掌瓦核对";
                            else if(Alerts.send(this,"萨摩耶开商店 · 今日皮肤",ShopText.lines(list),411)) transientStatus="已执行，四款皮肤已发送到通知栏";
                            else transientStatus="查询成功，但通知被系统拦截，请检查通知权限";
                        } catch(JSONException e) { transientStatus="商品格式异常，未发送通知"; }
                    }
                });
            } catch(Exception e) { runOnUiThread(()-> { if(generation==accountGeneration) transientStatus=friendly(e); }); }
            finally { runOnUiThread(()-> { busy=false; if(!isDestroyed()) render(); }); }
        });
    }
    private void loginPage() {
        body.addView(label("把商店交给萨摩耶",27,WHITE)); gap(body,8);
        body.addView(label("使用自己的 QQ 或微信扫码授权。登录信息只加密保存在本机。",14,MUTED));
        button(body,"QQ 扫码登录",true,()->login("qq")); button(body,"微信扫码登录",false,()->login("wechat"));
        loginStatus=label(activeLogin!=null&&!activeLogin.isDone()?"等待扫码确认…":session()==null?"尚未登录":"已登录，可切换账号或重新授权",14,ACCENT);
        gap(body,18); body.addView(loginStatus);
        if(qrBytes!=null) showQr();
        LinearLayout note=card(body); note.addView(label("卓易通登录提示",16,WHITE)); gap(note,8);
        note.addView(label("卓易通内可能无法直接调起 QQ / 微信。请用另一台已登录 QQ / 微信的手机扫描二维码；普通安卓也可尝试保存二维码后从相册识别。二维码过期可重新生成。",13,MUTED));
        if(activeLogin!=null&&!activeLogin.isDone()) button(body,"取消本次扫码",false,()-> { stopLogin(); render(); });
        if(session()!=null) button(body,"退出登录并关闭提醒",false,()->new AlertDialog.Builder(this).setTitle("退出当前账号？").setMessage("将删除本机登录凭证和商店缓存，并关闭自动提醒。").setNegativeButton("取消",null).setPositiveButton("退出",(d,w)->logout()).show());
    }
    private void showQr() {
        Bitmap bitmap=BitmapFactory.decodeByteArray(qrBytes,0,qrBytes.length);
        if(bitmap==null) { loginStatus.setText("二维码图片无法显示，请重新生成"); return; }
        ImageView qr=new ImageView(this); qr.setImageBitmap(bitmap); qr.setBackgroundColor(Color.WHITE); qr.setPadding(dp(12),dp(12),dp(12),dp(12));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(240),dp(240)); lp.gravity=Gravity.CENTER_HORIZONTAL; lp.topMargin=dp(20); body.addView(qr,lp);
        button(body,"保存二维码",false,()-> {
            saveBytes=qrBytes.clone();
            Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("image/png").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"萨摩耶开商店-登录二维码.png");
            try { startActivityForResult(save,31); } catch(Exception e) { toast("当前系统没有可用的文件保存工具，请用另一台手机扫码"); }
        });
    }
    private void stopLogin() { if(activeLogin!=null) activeLogin.cancel(true); activeLogin=null; qrBytes=null; accountGeneration++; }
    private void login(String mode) {
        stopLogin(); final int generation=accountGeneration;
        activeLogin=io.submit(()-> {
            try {
                LoginFlow flow=new LoginFlow(new LoginFlow.Display() {
                    @Override public void qr(byte[] bytes,String message) { runOnUiThread(()-> { if(generation!=accountGeneration||isDestroyed()) return; qrBytes=bytes; if(page==1) { render(); loginStatus.setText(message); } }); }
                    @Override public void status(String message) { runOnUiThread(()-> { if(generation==accountGeneration&&page==1&&loginStatus!=null) loginStatus.setText(message); }); }
                });
                JSONObject result=mode.equals("qq")?flow.qq():flow.wechat();
                runOnUiThread(()-> {
                    if(generation!=accountGeneration||isDestroyed()) return;
                    try {
                        synchronized(ShopJob.LOCK) {
                            new Vault(this).save(result);
                            prefs.edit().remove("cache").remove("cacheAt").remove("notifiedDay").remove("expiredDay").putString("status","已登录").apply();
                        }
                        qrBytes=null; activeLogin=null; page=0; transientStatus="登录成功，正在查询商店"; refresh(false);
                    } catch(Exception e) { toast("登录信息保存失败，请重试"); }
                });
            } catch(InterruptedException ignored) { Thread.currentThread().interrupt(); }
            catch(Exception e) { runOnUiThread(()-> { if(generation!=accountGeneration||isDestroyed()) return; activeLogin=null; qrBytes=null; render(); if(page==1) loginStatus.setText(friendly(e)); }); }
        });
        page=1; render();
    }
    private void logout() {
        stopLogin();
        synchronized(ShopJob.LOCK) { new Vault(this).clear(); prefs.edit().clear().apply(); ShopJob.cancel(this); }
        getSystemService(NotificationManager.class).cancelAll(); transientStatus="已退出登录"; render();
    }
    private void settingsPage() {
        body.addView(label("每天，准时惦记你",27,WHITE)); gap(body,8);
        body.addView(label("通知只发四行：皮肤名称 + VP 价格。",14,MUTED));
        LinearLayout preview=card(body); preview.addView(label("通知样式 · 示例",12,ACCENT)); gap(preview,12);
        TextView sample=label("盖亚的复仇 狂徒    1290vp\n侦察力量 幻影       1290vp\n其余两款皮肤        …vp",14,WHITE); preview.addView(sample);
        LinearLayout settings=card(body);
        Switch enabled=new Switch(this); enabled.setText("每日自动提醒"); enabled.setTextColor(WHITE); enabled.setTextSize(17); enabled.setChecked(prefs.getBoolean("enabled",false)); settings.addView(enabled);
        enabled.setOnCheckedChangeListener((b,on)-> {
            if(on && session()==null) { b.setChecked(false); toast("请先登录 QQ 或微信"); return; }
            if(on && !Alerts.allowed(this)) {
                b.setChecked(false);
                if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},21);
                else openNotifications();
                toast("请允许通知后，再开启自动提醒"); return;
            }
            synchronized(ShopJob.LOCK) { prefs.edit().putBoolean("enabled",on).apply(); }
            if(on) { if(!ShopJob.schedule(this)) { prefs.edit().putBoolean("enabled",false).apply(); b.setChecked(false); toast("系统未接受后台任务，请重试"); } }
            else ShopJob.cancel(this);
        });
        int hour=prefs.getInt("hour",8),minute=prefs.getInt("minute",30);
        button(settings,String.format(java.util.Locale.ROOT,"提醒时间    %02d:%02d",hour,minute),false,()->new TimePickerDialog(this,(view,h,m)-> {
            prefs.edit().putInt("hour",h).putInt("minute",m).apply(); AlarmReceiver.schedule(this); render();
        },hour,minute,true).show());
        gap(settings,12); settings.addView(label("跟随手机系统时间与时区，默认每天 08:30。今天自动提醒成功后不重复；手动执行可再次弹窗。省电、断网或卓易通后台限制可能导致延迟，强行停止后需再次打开。",12,MUTED));
        button(body,AlarmReceiver.exactAllowed(this)?"准时调度：已获系统允许":"允许闹钟和提醒（提高准时性）",false,()-> {
            if(Build.VERSION.SDK_INT>=31 && !AlarmReceiver.exactAllowed(this)) {
                try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName()))); }
                catch(Exception e) { toast("当前环境未提供闹钟授权设置，将使用系统普通调度"); }
            } else toast("已允许精确调度，网络和卓易通后台仍可能造成延后");
        });
        button(body,"发送一条通知测试",true,()->testNotice());
        button(body,"打开系统通知设置",false,()->openNotifications());
        button(body,"查看手机后台设置",false,()-> {
            try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName()))); }
            catch(Exception e) { toast("请在卓易通应用管理中允许后台消息和通知"); }
        });
        LinearLayout harmony=card(body); harmony.addView(label("鸿蒙 / 卓易通",16,WHITE)); gap(harmony,8);
        harmony.addView(label("请在卓易通的应用管理中开启本应用的通知和后台消息，并允许卓易通自身在鸿蒙后台运行。是否能持续提醒需要在你的手机实测。",13,MUTED));
        gap(body,12); body.addView(label("当前状态："+prefs.getString("status","等待首次查询"),13,MUTED));
    }
    private void testNotice() {
        if(!Alerts.allowed(this)) {
            if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},21);
            else openNotifications();
            return;
        }
        try {
            JSONArray cache=new JSONArray(prefs.getString("cache","[]"));
            String text=cache.length()>0?ShopText.lines(cache):"盖亚的复仇 狂徒    1290vp\n侦察力量 幻影    1290vp\n示例皮肤三    1290vp\n示例皮肤四    1290vp";
            Alerts.send(this,cache.length()>0?"通知测试 · 上次查询结果":"通知测试 · 示例数据",text,413);
            toast("已发送，可展开通知查看四行内容");
        } catch(JSONException e) { toast("缓存无法读取，请重新查询"); }
    }
    private void openNotifications() {
        try { startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName())); }
        catch(Exception e) { toast("请在卓易通的应用管理中打开本应用通知"); }
    }
    private String friendly(Exception e) {
        if(e instanceof java.net.SocketTimeoutException || e instanceof java.net.UnknownHostException) return "网络连接失败，请检查网络后重试";
        if(e instanceof java.io.IOException) return e.getMessage()==null?"请求失败，请重试":e.getMessage();
        return "服务响应暂无法解析，接口可能已变化，请稍后重试";
    }
    private void toast(String message) { Toast.makeText(this,message,Toast.LENGTH_LONG).show(); }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] grants) {
        super.onRequestPermissionsResult(request,permissions,grants);
        if(request==21) { toast(Alerts.allowed(this)?"已允许通知，可开启提醒或发送测试":"未允许通知，暂时无法提醒"); render(); }
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if(request==31 && result==RESULT_OK && data!=null && data.getData()!=null && saveBytes!=null) {
            try(java.io.OutputStream out=getContentResolver().openOutputStream(data.getData())) { if(out==null) throw new java.io.IOException(); out.write(saveBytes); toast("二维码已保存，请在 QQ / 微信中尝试相册识别"); }
            catch(Exception e) { toast("保存失败，请用另一台手机扫码"); }
        }
        saveBytes=null;
    }
    @Override protected void onDestroy() { stopLogin(); io.shutdownNow(); super.onDestroy(); }
    @Override protected void onResume() { super.onResume(); if(prefs!=null && prefs.getBoolean("enabled",false)) AlarmReceiver.schedule(this); }
}
