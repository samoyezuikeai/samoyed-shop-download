package cn.wadian.app;

import org.json.*;
import android.util.Base64;
import java.io.IOException;
import java.util.*;
import java.util.regex.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/** Protocol implementation; credentials come only from the user's explicit scan/confirmation. */
public final class LoginFlow {
    public interface Display { void qr(byte[] png, String message); void status(String message); }
    private final Net net = new Net();
    private final Display display;
    public LoginFlow(Display display) { this.display = display; }
    private static void pause() throws InterruptedException { Thread.sleep(2000); }
    static String match(String input, String pattern) {
        Matcher m = Pattern.compile(pattern).matcher(input); return m.find() ? m.group(1) : "";
    }
    public JSONObject wechat() throws Exception {
        String app = "wxcbb49f1f39656c2a";
        JSONObject ticket = net.post(ShopApi.ROOT+"auth/get_sdk_ticket", ShopApi.envelope().put("sdk_appid", app).put("mcode","69028af6dca2c107f4f58290100011b1a303"), null);
        JSONObject data = ticket.optJSONObject("data");
        String value = data == null ? "" : data.optString("ticket");
        if (value.isEmpty()) throw new IOException("微信授权服务暂不可用，请重试");
        String nonce = UUID.randomUUID().toString().replace("-", "").substring(0, 12);
        String time = Long.toString(System.currentTimeMillis()/1000);
        byte[] digest = MessageDigest.getInstance("SHA-1").digest(("appid="+app+"&noncestr="+nonce+"&sdk_ticket="+value+"&timestamp="+time).getBytes(StandardCharsets.UTF_8));
        StringBuilder hex = new StringBuilder(); for (byte b : digest) hex.append(String.format(Locale.ROOT, "%02x", b & 255));
        JSONObject qr = new JSONObject(net.text(Net.query("https://open.weixin.qq.com/connect/sdk/qrconnect?f=json",
                Net.fields("appid",app,"noncestr",nonce,"timestamp",time,"scope","snsapi_userinfo","signature",hex.toString()))));
        if (qr.optInt("errcode", -1) != 0) throw new IOException("微信二维码生成失败，请重试");
        String image = qr.getJSONObject("qrcode").getString("qrcodebase64");
        display.qr(Base64.decode(image.substring(image.indexOf(',')+1), Base64.DEFAULT), "请使用微信扫码并确认登录。可保存二维码后尝试从相册识别。");
        long deadline = android.os.SystemClock.elapsedRealtime()+180000;
        String last = "";
        while (android.os.SystemClock.elapsedRealtime() < deadline) {
            pause();
            String raw = net.text("https://long.open.weixin.qq.com/connect/l/qrconnect?f=json&uuid="+Net.enc(qr.getString("uuid"))+(last.isEmpty()?"":"&last="+last));
            String code;
            try {
                JSONObject state = new JSONObject(raw); last = state.optString("wx_errcode"); code = state.optString("wx_code");
            } catch (JSONException e) { last = match(raw,"wx_errcode\\s*=\\s*(\\d+)"); code = match(raw,"wx_code\\s*=\\s*['\"]([^'\"]+)['\"]"); }
            if (!code.isEmpty() && (last.equals("405") || last.equals("0"))) {
                display.status("正在完成微信登录…");
                return ShopApi.login(net, "wechat", new JSONObject().put("appid",app).put("check_third_type",1).put("code",code).put("wx_info_type",1));
            }
            if (last.equals("404")) display.status("已扫描，请在微信中确认");
            else if (!last.equals("408") && !last.equals("0")) throw new IOException("微信二维码已过期或授权已取消，请重试");
        }
        throw new IOException("二维码已过期，请重新生成");
    }
    public JSONObject qq() throws Exception {
        Map<String,String> init = new LinkedHashMap<>();
        init.put("appid","716027609"); init.put("pt_3rd_aid","102061775"); init.put("daid","381");
        init.put("style","35"); init.put("force_qr","1"); init.put("autorefresh","1");
        init.put("s_url","https://connect.qq.com"); init.put("refer_cgi","m_authorize");
        init.put("redirect_uri","auth://tauth.qq.com/"); init.put("client_id","102061775");
        init.put("pf","openmobile_android"); init.put("response_type","token"); init.put("scope","all");
        init.put("sdkp","a"); init.put("sdkv","3.5.17.lite"); init.put("switch","1");
        String page = net.text(Net.query("https://xui.ptlogin2.qq.com/cgi-bin/xlogin",init));
        String version = match(page,"(?:ptuiV|js_ver)\\s*=\\s*['\"]([^'\"]+)['\"]");
        String loginSig = net.cookie("pt_login_sig");
        byte[] png = net.get(Net.query("https://xui.ptlogin2.qq.com/ssl/ptqrshow", Net.fields("appid","716027609","pt_3rd_aid","102061775","daid","381","s","8","e","0","type","0","u1","https://connect.qq.com","t",Double.toString(Math.random()))));
        String sig = net.cookie("qrsig");
        if (sig.isEmpty()) throw new IOException("QQ 授权会话未建立，请重试");
        int token=0; for (char c : sig.toCharArray()) token += (token << 5) + c;
        display.qr(png,"请使用 QQ 扫码并确认登录。可保存二维码后尝试从相册识别。");
        Map<String,String> poll = new LinkedHashMap<>();
        poll.put("u1","https://connect.qq.com"); poll.put("from_ui","1"); poll.put("type","1");
        poll.put("ptlang","2052"); poll.put("ptqrtoken",Integer.toString(token & 0x7fffffff));
        poll.put("daid","381"); poll.put("aid","716027609"); poll.put("pt_3rd_aid","102061775");
        poll.put("device","2"); poll.put("ptopt","1"); poll.put("pt_uistyle","35");
        poll.put("login_sig",loginSig); if(!version.isEmpty()) poll.put("jsver",version);
        Map<String,String> open = new LinkedHashMap<>(init); open.remove("appid"); open.remove("daid");
        open.put("openapi","1011"); open.put("src","1"); open.put("need_pay","0"); open.put("browser","0");
        poll.put("pt_openlogin_data",Net.query("https://placeholder.invalid/",open).split("\\?",2)[1]);
        long deadline = android.os.SystemClock.elapsedRealtime()+180000;
        while (android.os.SystemClock.elapsedRealtime() < deadline) {
            pause(); poll.put("r",Double.toString(Math.random()));
            String raw = net.text(Net.query("https://xui.ptlogin2.qq.com/ssl/ptqrlogin",poll));
            Matcher cb = Pattern.compile("ptuiCB\\('([^']*)','[^']*','([^']*)'").matcher(raw);
            if (!cb.find()) throw new IOException("QQ 登录响应格式发生变化，请稍后重试");
            String code = cb.group(1);
            if (code.equals("0")) {
                display.status("正在完成 QQ 登录…");
                Map<String,String> params = resolve(cb.group(2).replace("\\x26","&").replace("\\/","/"));
                String openid = params.getOrDefault("openid", ""), access = params.getOrDefault("access_token", "");
                if (openid.isEmpty() || access.isEmpty()) throw new IOException("QQ 已确认，但未取得授权凭证。登录协议可能已变化，请尝试微信登录");
                return ShopApi.login(net,"qq",new JSONObject().put("appid",102061775).put("openid",openid).put("sig",access).put("qq_info_type",5).put("uin",0));
            }
            if (code.equals("65")) throw new IOException("QQ 二维码已过期，请重试");
            if (code.equals("67")) display.status("已扫描，请在 QQ 中确认");
            else if (!code.equals("66")) throw new IOException("QQ 授权未完成（"+code+"），请重试");
        }
        throw new IOException("二维码已过期，请重新生成");
    }
    private Map<String,String> resolve(String address) throws Exception {
        Map<String,String> all = new HashMap<>(); Set<String> seen = new HashSet<>();
        for (int i=0; i<8 && seen.add(address); i++) {
            collect(address,all);
            if (all.containsKey("openid") && all.containsKey("access_token")) return all;
            String key = all.getOrDefault("keystr",all.getOrDefault("redirect_uri_key",net.cookie("keystr")));
            if (!key.isEmpty()) {
                String response = net.text("https://openmobile.qq.com/oauth2.0/m_get_redirect_url?keystr="+Net.enc(key));
                String callback = match(response.replace("\\/","/"),"(auth://tauth\\.qq\\.com/[^\\s\"'<>]+)");
                if (!callback.isEmpty()) { address=callback; continue; }
            }
            if (!address.startsWith("https://")) break;
            String next=net.text(address);
            if (next.startsWith("https://") || next.startsWith("auth://")) { address=next; continue; }
            String extracted=match(next.replace("\\/","/"),"(?:url|location\\.href)\\s*[:=]\\s*['\"]([^'\"]+)['\"]");
            if (extracted.isEmpty()) break; address=extracted;
        }
        return all;
    }
    private void collect(String raw, Map<String,String> result) {
        String value=raw;
        for(int pass=0;pass<3;pass++) {
            Matcher m=Pattern.compile("(?:[?&#]|^)(openid|access_token|keystr|redirect_uri_key)=([^&#]*)").matcher(value);
            while(m.find()) result.put(m.group(1),Net.dec(m.group(2)));
            try { value=Net.dec(value); } catch(IllegalArgumentException e) { break; }
        }
    }
}
