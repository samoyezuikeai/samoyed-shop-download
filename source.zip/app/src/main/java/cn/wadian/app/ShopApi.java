package cn.wadian.app;

import org.json.*;
import java.io.IOException;

public final class ShopApi {
    static final String ROOT = "https://app.mval.qq.com/go/";
    public static class LoginExpired extends IOException { public LoginExpired() { super("登录已过期，请重新登录 QQ 或微信"); } }
    public static JSONObject envelope() throws JSONException {
        return new JSONObject().put("clienttype", 9).put("mappid", 10200)
            .put("config_params", new JSONObject().put("client_dev_name", "Android").put("lang_type", 0))
            .put("source_game_zone", "agame").put("game_zone", "agame");
    }
    public static JSONObject login(Net net, String mode, JSONObject identity) throws Exception {
        JSONObject body = envelope().put("login_info", identity).put("mcode", mode.equals("qq") ? "132f0a77d34402abc8463d60100011d19b0e" : "69028af6dca2c107f4f58290100011b1a303");
        JSONObject response = net.post(ROOT + "auth/login_by_" + mode + "?source_game_zone=agame&game_zone=agame", body,
                "clientType=9; openid=null; access_token=null;");
        JSONObject data = response.optJSONObject("data");
        JSONObject info = data == null ? null : data.optJSONObject("login_info");
        if (response.optInt("result", -1) != 0 || info == null || info.optInt("result", 0) != 0
                || info.optString("user_id").isEmpty() || info.optString("wt").isEmpty())
            throw new IOException("掌瓦登录未成功，可能需要先在官方 App 绑定角色，或登录接口已变化");
        return new JSONObject().put("userId", info.getString("user_id")).put("tid", info.getString("wt"))
                .put("openid", info.optString("openid", identity.optString("openid")))
                .put("uin", info.optString("uin", "0")).put("mode", mode);
    }
    public static JSONArray fetch(JSONObject session) throws Exception {
        if (session == null) throw new LoginExpired();
        String cookie = "clientType=9; userId=" + safe(session.getString("userId"))
                + "; tid=" + safe(session.getString("tid")) + "; accountType=5; openid=" + safe(session.optString("openid"))
                + "; uin=o" + safe(session.optString("uin", "0")) + "; appid="
                + (session.optString("mode").equals("wechat") ? "wxcbb49f1f39656c2a; acctype=wx" : "102061775; acctype=qc");
        JSONObject response = new Net().post(ROOT + "mlol_store/agame/user_store?source_game_zone=agame&game_zone=agame", new JSONObject().put("_t", System.currentTimeMillis()/1000).put("source_game_zone","agame").put("game_zone","agame"), cookie);
        return parse(response);
    }
    public static JSONArray parse(JSONObject response) throws Exception {
        int code = response.optInt("result", -1);
        String message = response.optString("errMsg", response.optString("msg", ""));
        if (code == 1001 || code == 1003 || code == 999999 || message.toLowerCase(java.util.Locale.ROOT).contains("ticket")) throw new LoginExpired();
        if (code != 0) throw new IOException("商店接口返回错误（" + code + "），请稍后重试或重新登录");
        Object raw = response.opt("data");
        JSONObject data = raw instanceof JSONObject ? (JSONObject)raw : null;
        if(raw instanceof JSONArray) {
            JSONArray sections=(JSONArray)raw;
            for(int i=0;i<sections.length();i++) {
                JSONObject section=sections.optJSONObject(i);
                if(section!=null && section.optString("key").equals("dailystore")) { data=section; break; }
            }
            if(data==null && sections.length()==1 && sections.optJSONObject(0)!=null && !sections.getJSONObject(0).has("key")) data=sections.getJSONObject(0);
        }
        JSONArray list = data == null ? null : data.optJSONArray("list");
        if (list == null || list.length() == 0) throw new IOException("商店暂无数据，请先在官方掌瓦确认已授权游戏角色");
        for (int i=0; i<list.length(); i++) {
            if (list.getJSONObject(i).optString("goods_name").isEmpty()) throw new IOException("商店数据格式已变化");
        }
        return list;
    }
    static String safe(String value) throws IOException {
        if (!value.matches("[A-Za-z0-9_./+=:@%-]*")) throw new IOException("登录凭证格式异常，请重新登录");
        return value;
    }
}
