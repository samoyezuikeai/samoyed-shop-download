package cn.wadian.app;

import java.net.URI;
import java.util.*;

public final class CookiesCheck {
    private static int count;
    static void check(boolean ok,String what) { if(!ok) throw new AssertionError(what); count++; }
    public static void main(String[] args) {
        URI origin=URI.create("https://xui.ptlogin2.qq.com/ssl/ptqrshow");
        SessionCookies jar=new SessionCookies();
        jar.receive(origin,Collections.singletonMap("Set-Cookie",Arrays.asList("qrsig=example; Path=/; Domain=ptlogin2.qq.com; Secure; SameSite=None")));
        check(jar.value("qrsig").equals("example"),"unprefixed Domain is retained");
        check(jar.header(URI.create("https://xui.ptlogin2.qq.com/ssl/ptqrlogin")).equals("qrsig=example"),"QQ poll receives qrsig");
        check(jar.header(URI.create("https://ssl.ptlogin2.qq.com/ptqrlogin")).contains("qrsig=example"),"domain cookie shared with real sibling");
        check(jar.header(URI.create("https://app.mval.qq.com/")).isEmpty(),"no credential leaks to unrelated app host");
        check(jar.header(URI.create("https://notptlogin2.qq.com/")).isEmpty(),"host boundary");
        check(jar.header(URI.create("http://xui.ptlogin2.qq.com/")).isEmpty(),"secure cookie not sent over HTTP");
        jar.receive(origin,Collections.singletonMap("set-cookie",Arrays.asList("host=yes; Path=/")));
        check(jar.header(URI.create("https://ssl.ptlogin2.qq.com/")).equals("qrsig=example"),"host-only cookie isolated");
        jar.receive(origin,Collections.singletonMap("Set-Cookie",Arrays.asList("bad=value; Domain=com; Path=/","foreign=value; Domain=attacker.qq.com; Path=/")));
        check(jar.value("bad").isEmpty()&&jar.value("foreign").isEmpty(),"reject foreign and public suffix domains");
        jar.receive(origin,Collections.singletonMap("Set-Cookie",Arrays.asList("limited=yes; Path=/ssl")));
        check(jar.header(URI.create("https://xui.ptlogin2.qq.com/ssl/ptqrlogin")).contains("limited=yes"),"path child");
        check(!jar.header(URI.create("https://xui.ptlogin2.qq.com/sslfake")).contains("limited=yes"),"path boundary");
        jar.receive(origin,Collections.singletonMap("Set-Cookie",Arrays.asList("qrsig=gone; Domain=ptlogin2.qq.com; Path=/; Max-Age=0")));
        check(jar.value("qrsig").isEmpty(),"cookie deletion");
        System.out.println(count+" cookie checks passed");
    }
}
