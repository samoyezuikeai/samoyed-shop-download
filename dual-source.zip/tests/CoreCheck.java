package cn.wadian.app;
import org.json.*;
import java.time.*;
import java.util.*;

/** Run without a device: scheduling, daily dedup, section selection, error and price semantics. */
public final class CoreCheck {
    private static int checks;
    private static void check(boolean ok,String what) { if(!ok) throw new AssertionError(what); checks++; }
    public static void main(String[] args) throws Exception {
        TimeZone previous=TimeZone.getDefault();
        try {
            TimeZone.setDefault(TimeZone.getTimeZone("Asia/Shanghai"));
            Instant before=Instant.parse("2026-10-22T00:29:59Z"), due=Instant.parse("2026-10-22T00:30:00Z");
            check(!StoreClock.due(before,8,30,""),"before 08:30 must not notify");
            check(StoreClock.due(due,8,30,""),"08:30 is due");
            check(!StoreClock.due(due,8,30,"2026-10-22"),"same day dedup");
            check(StoreClock.due(due.plusSeconds(86400),8,30,"2026-10-22"),"next day not suppressed");
            check(!StoreClock.slot(due,8,30).equals(StoreClock.slot(due,11,30)),"changed reminder time invalidates old in-flight slot");
            check(StoreClock.slot(due,8,30).equals(StoreClock.slot(due.plusSeconds(20),8,30)),"same scheduled slot survives request latency");
            check(StoreClock.nextAlarm(before,8,30)==due.toEpochMilli(),"next alarm today");
            check(StoreClock.nextAlarm(due,8,30)==due.plusSeconds(86400).toEpochMilli(),"fired alarm schedules tomorrow");
            TimeZone.setDefault(TimeZone.getTimeZone("America/New_York"));
            Instant ny=Instant.parse("2026-10-22T12:30:00Z");
            check(StoreClock.zone().getId().equals("America/New_York"),"phone timezone change");
            check(StoreClock.due(ny,8,30,""),"08:30 phone time rather than Beijing time");
            check(StoreClock.nextAlarm(Instant.parse("2026-10-31T12:31:00Z"),8,30)==Instant.parse("2026-11-01T13:30:00Z").toEpochMilli(),"DST transition keeps wall clock 08:30");
        } finally { TimeZone.setDefault(previous); }
        JSONArray offers=new JSONArray();
        for(int i=0;i<4;i++) offers.put(new JSONObject().put("goods_name","皮肤"+i).put("rmb_price",1290));
        JSONObject response=new JSONObject().put("result",0).put("data",new JSONArray()
            .put(new JSONObject().put("key","bundle").put("list",new JSONArray().put(new JSONObject().put("goods_name","错误的礼包"))))
            .put(new JSONObject().put("key","dailystore").put("list",offers)));
        check(ShopApi.parse(response).length()==4,"select dailystore, never first bundle");
        check(ShopApi.parse(response).getJSONObject(0).getString("goods_name").equals("皮肤0"),"daily skin data");
        String lines=ShopText.lines(offers);
        check(lines.split("\n").length==4,"four notification lines");
        check(lines.split("\n")[0].equals("皮肤0    1290vp"),"requested price format");
        check(ShopText.line(new JSONObject().put("goods_name","皮肤").put("vp_price","1775.0")).endsWith("1775vp"),"numeric normalization");
        check(ShopText.line(new JSONObject().put("goods_name","皮肤").put("rmb_price","¥129")).endsWith("价格待确认"),"do not convert currency into VP");
        check(ShopText.line(new JSONObject().put("goods_name","皮肤")).endsWith("价格待确认"),"missing price not zero");
        try { ShopApi.parse(new JSONObject().put("result",1001)); throw new AssertionError("expired session accepted"); }
        catch(ShopApi.LoginExpired expected) { checks++; }
        try { ShopApi.parse(new JSONObject().put("result",0).put("data",new JSONArray())); throw new AssertionError("empty data accepted"); }
        catch(java.io.IOException expected) { checks++; }
        try { ShopApi.safe("token; forged=yes"); throw new AssertionError("cookie injection accepted"); }
        catch(java.io.IOException expected) { checks++; }
        check(ShopApi.safe("ticket|segment~[]{}").equals("ticket|segment~[]{}"),"valid ticket punctuation preserved");
        try { ShopApi.safe("token\r\nInjected: yes"); throw new AssertionError("header injection accepted"); }
        catch(java.io.IOException expected) { checks++; }
        System.out.println(checks+" checks passed");
    }
}
