package cn.wadian.app;
import java.time.*;
import java.util.TimeZone;

/** Regressions for reboot catch-up and independent background deadline checks. */
public final class BackgroundClockCheck {
    static int checks;
    static void check(boolean ok,String message) { if(!ok) throw new AssertionError(message); checks++; }
    public static void main(String[] args) {
        TimeZone saved=TimeZone.getDefault();
        try {
            TimeZone.setDefault(TimeZone.getTimeZone("Asia/Shanghai"));
            Instant deadline=Instant.parse("2026-10-26T00:30:00Z");
            check(StoreClock.pendingDay(deadline.minusSeconds(1),8,30,"",0)==null,"newly enabled future deadline must wait");
            check("2026-10-26".equals(StoreClock.pendingDay(deadline,8,30,"",0)),"resident clock detects due deadline without a receiver event");
            check("2026-10-26".equals(StoreClock.pendingDay(deadline.plusSeconds(600),8,30,"",deadline.toEpochMilli())),"same-day boot after missed alarm catches up");
            check(StoreClock.pendingDay(deadline.plusSeconds(600),8,30,"2026-10-26",deadline.toEpochMilli())==null,"completed reminder never repeats on recovery");
            Instant nextMorning=Instant.parse("2026-10-26T23:00:00Z");
            check("2026-10-26".equals(StoreClock.pendingDay(nextMorning,8,30,"",deadline.toEpochMilli())),"overnight shutdown catches previous pending deadline");
            check(StoreClock.pendingDay(nextMorning,8,30,"2026-10-26",deadline.toEpochMilli())==null,"overnight catch-up deduplicated");
            check(StoreClock.pendingDay(nextMorning,8,30,"",0)==null,"first launch does not invent a missed deadline");
            check(StoreClock.pendingDay(nextMorning,8,30,"",nextMorning.plusSeconds(5400).toEpochMilli())==null,"future planned alarm is not missed");
            check(StoreClock.pendingDay(nextMorning,8,30,"2026-10-27",deadline.toEpochMilli())==null,"current-day completion suppresses historical recovery");
            check("2026-10-27".equals(StoreClock.pendingDay(deadline.plusSeconds(86400),8,30,"2026-10-26",0)),"next day works after catch-up");
            check(StoreClock.pendingDay(deadline,11,30,"",0)==null,"reconfigured later reminder waits after old target");
            check("2026-10-26".equals(StoreClock.pendingDay(deadline.plusSeconds(10800),11,30,"",0)),"reconfigured reminder executes at new target");
            System.out.println("BackgroundClockCheck: "+checks+" checks passed");
        } finally { TimeZone.setDefault(saved); }
    }
}
