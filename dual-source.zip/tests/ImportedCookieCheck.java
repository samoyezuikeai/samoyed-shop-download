package cn.wadian.app;
import org.json.*;
import java.io.IOException;

public final class ImportedCookieCheck {
    static int checks;
    static void check(boolean ok,String message) { if(!ok) throw new AssertionError(message); checks++; }
    static void reject(String input) throws Exception {
        try { ImportedCookie.parse(input); throw new AssertionError("Accepted malformed cookie"); }
        catch(IOException expected) { checks++; }
    }
    public static void main(String[] args) throws Exception {
        // All credentials below are synthetic test values, never live sessions.
        String raw="userId=synthetic-user; tid=a|b~[]{}==; clientType=10; accountType=2; acctype=wx; uin=o123";
        JSONObject imported=ImportedCookie.parse("Cookie: "+raw);
        check(imported.getString("mode").equals("cookie"),"mark imported origin");
        check(ShopApi.requestCookie(imported).equals(raw),"preserve existing platform/account type; no QQ defaults");
        check(ImportedCookie.parse("userId=u; tid=t; tracking=omit; ct=never-refresh").getString("cookieHeader").equals("userId=u; tid=t"),"exclude tracking and client refresh ticket");
        check(ImportedCookie.parse("  cookie: userId=u; tid=t;  ").getString("tid").equals("t"),"header prefix and whitespace");
        reject("userId=u"); reject("tid=t"); reject("userId=; tid=t");
        reject("userId=u; tid=t\r\nX-Other: injected");
        reject("userId=u; tid=t\nother=header");
        reject("userId=u; tid=t; tid=duplicate");
        reject("userId=u; tid=with space");
        reject("userId=u; tid=\"quoted\"");
        reject("userId=u; tid=back\\slash");
        reject("userId=u; tid=t; missingEquals");
        reject("Set-Cookie: userId=u; tid=t");
        reject("x".repeat(32769));
        JSONObject scanned=new JSONObject().put("userId","u").put("tid","t").put("mode","qq").put("uin","123");
        check(ShopApi.requestCookie(scanned).contains("clientType=9"),"scan compatibility");
        check(ShopApi.requestCookie(scanned).contains("acctype=qc"),"QQ compatibility");
        System.out.println("ImportedCookieCheck: "+checks+" checks passed");
    }
}
