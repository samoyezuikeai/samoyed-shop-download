package cn.wadian.app;

/** Live anonymous QQ handshake probe: stops on the first 'waiting for scan' response. */
public final class QqInitProbe {
    private static final class Ready extends RuntimeException {}
    public static void main(String[] args) throws Exception {
        LoginFlow flow=new LoginFlow(new LoginFlow.Display() {
            public void qr(byte[] bytes,String message) {
                boolean image=bytes.length>8 && ((bytes[0]==(byte)0x89 && bytes[1]=='P') || (bytes[0]=='G' && bytes[1]=='I'));
                if(!image) throw new AssertionError("QR response is not an image");
                System.out.println("QQ anonymous session ready; image bytes="+bytes.length);
            }
            public void status(String message) {
                if(message.startsWith("等待 QQ")) { System.out.println("QQ server confirms waiting-for-scan state (66)"); throw new Ready(); }
            }
        });
        try { flow.qq(); throw new AssertionError("probe unexpectedly completed login"); }
        catch(Ready done) {}
    }
}
