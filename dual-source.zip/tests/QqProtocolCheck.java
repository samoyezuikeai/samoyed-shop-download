package cn.wadian.app;

import java.util.*;

public final class QqProtocolCheck {
    private static int count;
    static void check(boolean ok,String name) { if(!ok) throw new AssertionError(name); count++; }
    public static void main(String[] args) throws Exception {
        check(QqProtocol.sdkSign(1763280194L).equals("a6479455d3e49b597350f13f776a6288"),"SDK checksum matches published protocol sample");
        String liveUrl="https://xui.ptlogin2.qq.com/cgi-bin/xlogin?client_id=102061775&pt_3rd_aid=102061775&h5sig=issued-for-this-session&s_url=http%3A%2F%2Fconnect.qq.com";
        String html="<script>var src = \""+liveUrl.replace("&","\\x26")+"\";</script>";
        String parsed=QqProtocol.loginUrl(html);
        check(parsed.equals(liveUrl),"provider context and JS escapes preserved");
        Map<String,String> context=QqProtocol.params(parsed);
        check(context.get("s_url").equals("http://connect.qq.com"),"do not rewrite callback scheme");
        Map<String,String> serialized=QqProtocol.params("https://unused.invalid/?"+QqProtocol.openData(context,"session-id",1000000));
        check(serialized.get("h5sig").equals("issued-for-this-session"),"fresh provider h5sig forwarded");
        check(serialized.get("tid").equals("session-id"),"same session identifier");
        check(serialized.get("auth_time").equals("1000000"),"authorization timestamp");
        check(serialized.get("redirect_uri").equals("auth://tauth.qq.com/"),"redirect remains intact through encoding");
        QqProtocol.State waiting=QqProtocol.state("ptuiCB('66','0','','0','等待扫码','');");
        check(waiting.code.equals("66"),"waiting state");
        QqProtocol.State rejected=QqProtocol.state("ptuiCB('-1','0','','0','登录失败，请重试','');");
        check(rejected.code.equals("-1")&&!rejected.code.equals("0"),"never accept -1 as success");
        check(rejected.message.equals("登录失败，请重试"),"server error retained");
        QqProtocol.State success=QqProtocol.state("ptuiCB('0','0','auth://tauth.qq.com/#openid=sample\\x26access_token=test%2Bvalue%3D','0','登录成功','');");
        Map<String,String> credentials=QqProtocol.credentials(success.url);
        check(credentials.get("access_token").equals("test+value="),"decode token once, preserve plus");
        String nested=Net.query("https://connect.qq.com/",Net.fields("redirect_url",success.url));
        check(QqProtocol.credentials(nested).get("openid").equals("sample"),"nested callback");
        check(QqProtocol.state("ptuiCB('65','0','','0','已过期','');").code.equals("65"),"server expiry distinct from local wait");
        try { QqProtocol.loginUrl(html.replace("xui.ptlogin2.qq.com","attacker.invalid")); throw new AssertionError("foreign login page accepted"); }
        catch(java.io.IOException expected) { count++; }
        try { QqProtocol.state("unrelated page"); throw new AssertionError("malformed response accepted"); }
        catch(java.io.IOException expected) { count++; }
        check(new QqProtocol.State("-1","","error abcdef01234567890123456789").safeMessage().contains("[已隐藏]"),"diagnostics hide token-like strings");
        System.out.println(count+" QQ protocol checks passed");
    }
}
