package cn.wadian.app;

import org.json.*;
import java.nio.file.*;

/** Interactive local test. Tokens stay in memory and are never printed or written to disk. */
public final class LiveAccountProbe {
    public static void main(String[] args) {
        final String qrPath=args.length>0?args[0]:".tools/qq-live-test.png";
        final String[] last={""};
        LoginFlow flow=new LoginFlow(new LoginFlow.Display() {
            public void qr(byte[] bytes,String message) {
                try { Files.write(Paths.get(qrPath),bytes); }
                catch(Exception e) { throw new IllegalStateException("Cannot save test QR image"); }
                System.out.println("QR_READY "+qrPath);
                System.out.flush();
            }
            public void status(String message) {
                String phase=message.replaceAll("（剩余.*","");
                if(!phase.equals(last[0])) { System.out.println(phase); System.out.flush(); last[0]=phase; }
            }
        });
        try {
            JSONObject session=flow.qq();
            System.out.println("QQ_AUTH_AND_MVAL_LOGIN_OK");
            // Keep this session in memory if another fetch-stage bug is found; no need to re-scan.
            for(int attempt=0;attempt<8;attempt++) {
                try(java.net.URLClassLoader fresh=new java.net.URLClassLoader(new java.net.URL[]{Paths.get(".tools/test-classes").toUri().toURL()},LiveAccountProbe.class.getClassLoader()) {
                    @Override protected Class<?> loadClass(String name,boolean resolve) throws ClassNotFoundException {
                        if(name.startsWith("cn.wadian.app.") && !name.equals("cn.wadian.app.LiveAccountProbe")) {
                            Class<?> c=findLoadedClass(name); if(c==null) c=findClass(name); if(resolve) resolveClass(c); return c;
                        }
                        return super.loadClass(name,resolve);
                    }
                }) {
                    JSONArray items=(JSONArray)fresh.loadClass("cn.wadian.app.ShopApi").getMethod("fetch",JSONObject.class).invoke(null,session);
                    System.out.println("REAL_STORE_ITEMS="+items.length());
                    System.out.println(ShopText.lines(items));
                    return;
                } catch(java.lang.reflect.InvocationTargetException e) {
                    Throwable cause=e.getCause();
                    System.out.println("STORE_CHECK: "+(cause instanceof java.io.IOException?cause.getMessage():"响应格式待核对"));
                    for(String key:new String[]{"userId","tid","openid","uin"}) {
                        String value=session.optString(key);
                        System.out.println("FIELD "+key+" present="+!value.isEmpty()+" non-cookie-codepoints="+value.codePoints().filter(c->c<=32||c>=127||c==34||c==44||c==59||c==92).distinct().mapToObj(Integer::toHexString).collect(java.util.stream.Collectors.joining(",")));
                    }
                    System.out.println("SESSION_HELD_IN_MEMORY: press Enter after recompiling the fix (or stop the process)");
                    System.out.flush();
                    if(new java.io.BufferedReader(new java.io.InputStreamReader(System.in)).readLine()==null) return;
                }
            }
        } catch(Exception e) {
            String message=e instanceof java.io.IOException?e.getMessage():"服务响应未能解析（未输出原始响应，以保护登录信息）";
            System.out.println("TEST_FAILED: "+message);
            System.exit(1);
        }
    }
}
