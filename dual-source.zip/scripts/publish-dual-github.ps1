param([string]$ScanVersion='0.1.4',[string]$CookieVersion='0.2.2')
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$repo='repos/samoyezuikeai/samoyed-shop-download'
$request=Join-Path $root '.tools/dual-api-request.json'
function Api([string]$endpoint,[string]$method='GET',$body=$null) {
    if($null -ne $body) {
        [IO.File]::WriteAllText($request,($body|ConvertTo-Json -Depth 12 -Compress),[Text.UTF8Encoding]::new($false))
        $raw=& gh api $endpoint --method $method --input $request
    } else { $raw=& gh api $endpoint --method $method }
    if($LASTEXITCODE -ne 0) { throw "GitHub API failed: $endpoint" }
    return ($raw|ConvertFrom-Json)
}
$head=(Api "$repo/git/ref/heads/main").object.sha
$base=(Api "$repo/git/commits/$head").tree.sha
$tree=@()
foreach($name in @('index.html','dual.html','shop-mascot.png','dual-versions.txt','dual-sha256.txt','dual-source.zip','scan-download-qr.svg','cookie-download-qr.svg',"samoyed-shop-scan-$ScanVersion.apk","samoyed-shop-cookie-$CookieVersion.apk")) {
    $file=Join-Path $root ('github-download/'+$name)
    $blob=Api "$repo/git/blobs" 'POST' @{encoding='base64';content=[Convert]::ToBase64String([IO.File]::ReadAllBytes($file))}
    $tree+=@{path=$name;mode='100644';type='blob';sha=$blob.sha}
}
$newTree=Api "$repo/git/trees" 'POST' @{base_tree=$base;tree=$tree}
$commit=Api "$repo/git/commits" 'POST' @{message="Publish reminder scheduling update: scan $ScanVersion and Cookie $CookieVersion";tree=$newTree.sha;parents=@($head)}
if((Api "$repo/git/ref/heads/main").object.sha -ne $head) { throw 'Remote branch changed; refusing to replace it' }
$result=Api "$repo/git/refs/heads/main" 'PATCH' @{sha=$commit.sha;force=$false}
Write-Output ('Published dual download commit: '+$result.object.sha)
