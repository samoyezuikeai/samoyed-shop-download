param([ValidateSet('scan','cookie')][string]$Flavor='scan')
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$toolRoot = Join-Path $projectRoot '.tools'
$jdkRoot = 'C:\Program Files\Android\openjdk\jdk-21.0.8'
if ($env:JAVA_HOME) { $jdkRoot = $env:JAVA_HOME }
$sdkRoot = Join-Path $toolRoot 'android-sdk'
if ($env:ANDROID_HOME) { $sdkRoot = $env:ANDROID_HOME }
$buildTools = Join-Path $sdkRoot 'build-tools\35.0.0'
$androidJar = Join-Path $sdkRoot 'platforms\android-35\android.jar'
$relativeOut = "app\build\standalone-$Flavor"
$out = Join-Path $projectRoot $relativeOut
$classes = Join-Path $out 'classes'
$generated = Join-Path $out 'generated'
$dex = Join-Path $out 'dex'
$appConfig=Get-Content -LiteralPath (Join-Path $projectRoot 'app\build.gradle') -Raw
$versionName=[regex]::Match($appConfig,"versionName '([^']+)'").Groups[1].Value
$versionCode=[regex]::Match($appConfig,'versionCode (\d+)').Groups[1].Value
if(-not $versionName -or -not $versionCode) { throw 'Missing Android version configuration' }
if($Flavor -eq 'cookie') { $versionName='0.2.1'; $versionCode='5' }
New-Item -ItemType Directory -Force -Path $out,$classes,$generated,$dex | Out-Null
function Run-Tool([string]$executable, [string[]]$arguments) {
    & $executable @arguments
    if ($LASTEXITCODE -ne 0) { throw "Tool failed: $executable ($LASTEXITCODE)" }
}
Set-Location -LiteralPath $projectRoot
# Native SDK binaries on Windows require relative paths in a non-ASCII workspace.
$relativeJar = [System.IO.Path]::GetRelativePath($projectRoot,$androidJar)
$manifest=Get-Content -LiteralPath 'app\src\main\AndroidManifest.xml' -Raw
if($Flavor -eq 'cookie') {
    $manifest=$manifest.Replace('package="cn.wadian.app"','package="cn.wadian.app.cookie"').Replace('android:name=".','android:name="cn.wadian.app.').Replace('android:label="萨摩耶开商店"','android:label="萨摩耶开商店·Cookie"')
}
[IO.File]::WriteAllText((Join-Path $out 'AndroidManifest.xml'),$manifest,[Text.UTF8Encoding]::new($false))
Run-Tool (Join-Path $buildTools 'aapt2.exe') @('compile','--dir','app\src\main\res','-o',"$relativeOut\resources.zip")
Run-Tool (Join-Path $buildTools 'aapt2.exe') @('link','-o',"$relativeOut\unsigned.apk",'-I',$relativeJar,'--manifest',"$relativeOut\AndroidManifest.xml",'--custom-package','cn.wadian.app','--java',"$relativeOut\generated",'--min-sdk-version','26','--target-sdk-version','35','--version-code',$versionCode,'--version-name',$versionName,'--auto-add-overlay',"$relativeOut\resources.zip")
$javaFiles = @((Get-ChildItem -LiteralPath (Join-Path $projectRoot 'app\src\main\java') -Recurse -Filter '*.java').FullName) + @((Get-ChildItem -LiteralPath $generated -Recurse -Filter '*.java').FullName)
Run-Tool (Join-Path $jdkRoot 'bin\javac.exe') (@('--release','17','-encoding','UTF-8','-classpath',$androidJar,'-d',$classes) + $javaFiles)
Add-Type -AssemblyName System.IO.Compression.FileSystem
$classArchive=Join-Path $out 'classes.jar'
if(Test-Path -LiteralPath $classArchive) { Remove-Item -LiteralPath $classArchive }
[System.IO.Compression.ZipFile]::CreateFromDirectory($classes,$classArchive)
Run-Tool (Join-Path $jdkRoot 'bin\java.exe') @('-cp',(Join-Path $buildTools 'lib\d8.jar'),'com.android.tools.r8.D8','--lib',$androidJar,'--min-api','26','--output',$dex,(Join-Path $out 'classes.jar'))
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [System.IO.Compression.ZipFile]::Open((Join-Path $out 'unsigned.apk'), [System.IO.Compression.ZipArchiveMode]::Update)
try {
    foreach ($dexFile in Get-ChildItem -LiteralPath $dex -Filter '*.dex') {
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive,$dexFile.FullName,$dexFile.Name) | Out-Null
    }
} finally { $archive.Dispose() }
Run-Tool (Join-Path $buildTools 'zipalign.exe') @('-f','-p','4',"$relativeOut\unsigned.apk","$relativeOut\aligned.apk")
$keystore = Join-Path $toolRoot 'local-test-signing.p12'
if (-not (Test-Path -LiteralPath $keystore)) {
    Run-Tool (Join-Path $jdkRoot 'bin\keytool.exe') @('-genkeypair','-keystore',$keystore,'-storepass','android','-alias','localtest','-keypass','android','-keyalg','RSA','-keysize','2048','-validity','3650','-dname','CN=Samoyed Local Test')
}
$apk = Join-Path $out "samoyed-shop-$Flavor-$versionName.apk"
Run-Tool (Join-Path $jdkRoot 'bin\java.exe') @('-jar',(Join-Path $buildTools 'lib\apksigner.jar'),'sign','--ks',$keystore,'--ks-key-alias','localtest','--ks-pass','pass:android','--key-pass','pass:android','--out',$apk,(Join-Path $out 'aligned.apk'))
Run-Tool (Join-Path $jdkRoot 'bin\java.exe') @('-jar',(Join-Path $buildTools 'lib\apksigner.jar'),'verify','--verbose',$apk)
Write-Output "APK: $apk"
