$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$repo='repos/samoyezuikeai/samoyed-shop-download'
$config=Get-Content -LiteralPath (Join-Path $root 'app\build.gradle') -Raw
$version=[regex]::Match($config,"versionName '([^']+)'").Groups[1].Value
if(-not $version) { throw 'Missing Android app version' }
$request=Join-Path $root '.tools\github-api-request.json'
function Api([string]$endpoint,[string]$method='GET',$body=$null) {
    if($null -ne $body) {
        [IO.File]::WriteAllText($request,($body|ConvertTo-Json -Depth 12 -Compress),[Text.UTF8Encoding]::new($false))
        $raw=& gh api $endpoint --method $method --input $request
    } else { $raw=& gh api $endpoint --method $method }
    if($LASTEXITCODE -ne 0) { throw "GitHub API failed: $endpoint" }
    return ($raw|ConvertFrom-Json)
}
$head=(Api "$repo/git/ref/heads/main").object.sha
$base=(Api "$repo/git/commits/$head").tree.sha
$tree=@()
foreach($name in @('index.html','privacy.html','README.md','download-qr.svg',"samoyed-shop-$version.apk",'sha256.txt','source.zip')) {
    $file=Join-Path $root ('github-download\'+$name)
    $blob=Api "$repo/git/blobs" 'POST' @{encoding='base64';content=[Convert]::ToBase64String([IO.File]::ReadAllBytes($file))}
    $tree+=@{path=$name;mode='100644';type='blob';sha=$blob.sha}
}
$newTree=Api "$repo/git/trees" 'POST' @{base_tree=$base;tree=$tree}
$commit=Api "$repo/git/commits" 'POST' @{message="Publish $version tested QQ login and updated download links";tree=$newTree.sha;parents=@($head)}
# Do not overwrite a concurrent update. The API also enforces fast-forward below.
if((Api "$repo/git/ref/heads/main").object.sha -ne $head) { throw 'Remote branch changed; refusing to replace it' }
$result=Api "$repo/git/refs/heads/main" 'PATCH' @{sha=$commit.sha;force=$false}
Write-Output ('Published website commit: '+$result.object.sha)
