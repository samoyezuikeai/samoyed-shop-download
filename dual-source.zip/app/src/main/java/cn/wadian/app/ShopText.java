package cn.wadian.app;

import org.json.*;

public final class ShopText {
    public static String line(JSONObject item) {
        String name=item.optString("goods_name", "未知皮肤").replaceAll("[\\r\\n]+", " ").trim();
        // The app service calls its point price rmb_price; preserve the numeric value, never convert money.
        String price=item.optString("vp_price", item.optString("rmb_price", "")).trim();
        if (!price.matches("\\d+(?:\\.0+)?")) return name + "    价格待确认";
        price=price.replaceFirst("\\.0+$", "");
        return name+"    "+price+"vp";
    }
    public static String lines(JSONArray list) throws JSONException {
        StringBuilder result=new StringBuilder();
        for(int i=0;i<list.length();i++) { if(i>0) result.append('\n'); result.append(line(list.getJSONObject(i))); }
        return result.toString();
    }
}
