package cn.wadian.app;

import java.io.IOException;
import java.net.URI;
import java.util.*;
import java.util.regex.*;

/** Parse provider-issued login context; do not invent or reuse a recorded h5sig. */
final class QqProtocol {
    /** SDK request checksum, based on public certificate metadata, not an APK private key. */
    static String sdkSign(long seconds) throws java.security.NoSuchAlgorithmException {
        String material="com.tencent.apps.valorant_304c3871ea696f1f96157840d33b413d_"+seconds;
        byte[] digest=java.security.MessageDigest.getInstance("MD5").digest(material.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        StringBuilder hex=new StringBuilder(); for(byte b:digest) hex.append(String.format(Locale.ROOT,"%02x",b&255));
        return hex.toString();
    }
    static String unescape(String value) {
        Matcher m=Pattern.compile("\\\\(?:x([0-9a-fA-F]{2})|u([0-9a-fA-F]{4}))").matcher(value);
        StringBuffer result=new StringBuffer();
        while(m.find()) m.appendReplacement(result,Matcher.quoteReplacement(Character.toString((char)Integer.parseInt(m.group(1)!=null?m.group(1):m.group(2),16))));
        m.appendTail(result);
        return result.toString().replace("\\/","/").replace("&amp;","&").replace("\\'","'").replace("\\\"","\"");
    }
    static String loginUrl(String html) throws IOException {
        Matcher m=Pattern.compile("\\bsrc\\s*=\\s*['\"]([^'\"]+)['\"]").matcher(html);
        while(m.find()) {
            String url=unescape(m.group(1));
            try {
                URI uri=URI.create(url);
                if("https".equals(uri.getScheme()) && "xui.ptlogin2.qq.com".equals(uri.getHost()) && "/cgi-bin/xlogin".equals(uri.getPath())) {
                    Map<String,String> q=params(url);
                    if("102061775".equals(q.get("client_id")) && "102061775".equals(q.get("pt_3rd_aid")) && !q.getOrDefault("h5sig","").isEmpty()) return url;
                }
            } catch(IllegalArgumentException ignored) {}
        }
        throw new IOException("QQ 官方授权页未返回有效登录上下文，请稍后重试（初始化阶段）");
    }
    static Map<String,String> params(String url) {
        Map<String,String> fields=new LinkedHashMap<>();
        for(String part:url.split("[?#]",3)) {
            for(String pair:part.split("&")) {
                int equal=pair.indexOf('='); if(equal<0) continue;
                try { fields.put(Net.dec(pair.substring(0,equal)),Net.dec(pair.substring(equal+1))); }
                catch(IllegalArgumentException ignored) {}
            }
        }
        return fields;
    }
    static String openData(Map<String,String> context,String id,long now) {
        Map<String,String> out=new LinkedHashMap<>();
        String[] keys={"which","refer_cgi","response_type","client_id","state","display","openapi","switch","src","sdkv","sdkp","tid","pf","need_pay","browser","browser_error","serial","token_key","redirect_uri","sign","time","status_version","status_os","status_machine","page_type","has_auth","update_auth","auth_time","loginfrom","h5sig","loginty"};
        Map<String,String> defaults=Net.fields("refer_cgi","m_authorize","response_type","token","client_id","102061775","openapi","1011","switch","1","src","1","sdkv","3.5.17.lite","sdkp","a","tid",id.isEmpty()?Long.toString(now/1000):id,"pf","openmobile_android","need_pay","0","browser","0","redirect_uri","auth://tauth.qq.com/","status_os","12","page_type","1","has_auth","1","update_auth","1","auth_time",Long.toString(now),"loginty","6");
        for(String key:keys) out.put(key,context.getOrDefault(key,defaults.getOrDefault(key,"")));
        return Net.query("https://unused.invalid/",out).split("\\?",2)[1];
    }
    static final class State {
        final String code,url,message;
        State(String code,String url,String message) { this.code=code; this.url=url; this.message=message; }
        String safeMessage() {
            String safe=message.replaceAll("https?://\\S+","[链接]").replaceAll("[A-Za-z0-9_+/=:%.-]{16,}","[已隐藏]").replaceAll("[\\r\\n]"," ");
            return safe.substring(0,Math.min(100,safe.length()));
        }
    }
    static State state(String body) throws IOException {
        int start=body.indexOf("ptuiCB("); if(start<0) throw new IOException("QQ 扫码状态响应格式已变化");
        List<String> args=new ArrayList<>();
        Matcher m=Pattern.compile("'((?:\\\\.|[^'\\\\])*)'").matcher(body.substring(start+7));
        while(m.find() && args.size()<6) args.add(unescape(m.group(1)));
        if(args.size()<5 || !args.get(0).matches("-?\\d+")) throw new IOException("QQ 扫码状态响应不完整");
        return new State(args.get(0),args.get(2),args.get(4));
    }
    static Map<String,String> credentials(String address) {
        Map<String,String> all=new HashMap<>(); Queue<String> queue=new ArrayDeque<>(); queue.add(unescape(address)); Set<String> seen=new HashSet<>();
        for(int i=0;!queue.isEmpty()&&i<20;i++) {
            String current=queue.remove(); if(!seen.add(current)) continue;
            Map<String,String> fields=params(current); all.putAll(fields);
            for(String key:new String[]{"u1","url","jump_url","redirect_uri","redirect_url","target_url","s_url","f_url","qtarget","jump","ru"}) {
                String nested=fields.get(key); if(nested!=null && !nested.isEmpty()) queue.add(nested);
            }
        }
        return all;
    }
}
