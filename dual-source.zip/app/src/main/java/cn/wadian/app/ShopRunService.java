package cn.wadian.app;

import android.app.*;
import android.content.*;
import android.os.*;
import java.util.concurrent.*;

/** Brief data-sync service, started only by a user-configured exact alarm. */
public final class ShopRunService extends Service {
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private volatile boolean stopped;
    private PowerManager.WakeLock wake;
    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        Alerts.setup(this);
        String channel="store-query-progress";
        NotificationManager manager=getSystemService(NotificationManager.class);
        manager.createNotificationChannel(new NotificationChannel(channel,"后台查询进度",NotificationManager.IMPORTANCE_LOW));
        Notification progress=new Notification.Builder(this,channel).setSmallIcon(R.drawable.ic_shop)
            .setContentTitle("萨摩耶正在查询商店").setContentText("查询完成后显示今日四款皮肤").setOngoing(true).build();
        try { startForeground(414,progress); }
        catch(RuntimeException e) { ShopJob.prefs(this).edit().putString("status","系统拒绝前台查询服务，将等待后台补查").apply(); stopSelf(startId); return START_NOT_STICKY; }
        if(wake==null) {
            wake=getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,getPackageName()+":shop-query");
            wake.acquire(60000);
        }
        executor.execute(()-> {
            try { StoreRunner.run(this,()->stopped); }
            finally { if(stopSelfResult(startId)) stopForeground(STOP_FOREGROUND_REMOVE); }
        });
        return START_NOT_STICKY;
    }
    @Override public void onDestroy() {
        stopped=true; executor.shutdownNow();
        if(wake!=null && wake.isHeld()) wake.release();
        super.onDestroy();
    }
}
