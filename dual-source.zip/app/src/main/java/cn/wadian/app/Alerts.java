package cn.wadian.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
import org.json.*;

public final class Alerts {
    public static final String CHANNEL="daily-store-v1";
    public static void setup(Context c) {
        NotificationChannel channel=new NotificationChannel(CHANNEL,"每日商店",NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("每日四款皮肤名称及 VP 价格");
        c.getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }
    public static boolean allowed(Context c) {
        if(Build.VERSION.SDK_INT>=33 && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) return false;
        NotificationManager manager=c.getSystemService(NotificationManager.class);
        NotificationChannel channel=manager.getNotificationChannel(CHANNEL);
        return manager.areNotificationsEnabled() && channel!=null && channel.getImportance()!=NotificationManager.IMPORTANCE_NONE;
    }
    public static boolean send(Context c, String title, String text, int id) {
        setup(c); if(!allowed(c)) return false;
        Intent intent=new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent open=PendingIntent.getActivity(c,0,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification note=new Notification.Builder(c,CHANNEL).setSmallIcon(R.drawable.ic_shop).setContentTitle(title)
            .setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text))
            .setContentIntent(open).setAutoCancel(true).setVisibility(Notification.VISIBILITY_PRIVATE).build();
        try { c.getSystemService(NotificationManager.class).notify(id,note); return true; }
        catch(SecurityException e) { return false; }
    }
}
