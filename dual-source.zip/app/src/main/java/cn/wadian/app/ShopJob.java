package cn.wadian.app;

import android.app.job.*;
import android.content.*;
import org.json.*;
import java.time.Instant;
import java.util.concurrent.*;

public final class ShopJob extends JobService {
    public static final Object LOCK=new Object();
    public static final int ID=410;
    private ExecutorService executor;
    private volatile boolean stopped;
    private int runningId=-1;
    public static android.content.SharedPreferences prefs(Context c) { return c.getSharedPreferences("settings",MODE_PRIVATE); }
    public static boolean schedule(Context c) {
        if(!prefs(c).getBoolean("enabled",false)) return false;
        JobInfo job=new JobInfo.Builder(ID,new ComponentName(c,ShopJob.class))
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPeriodic(15*60*1000L)
            .setPersisted(true).build();
        boolean ok=c.getSystemService(JobScheduler.class).schedule(job)==JobScheduler.RESULT_SUCCESS;
        AlarmReceiver.schedule(c);
        return ok;
    }
    public static void cancel(Context c) { c.getSystemService(JobScheduler.class).cancel(ID); c.getSystemService(JobScheduler.class).cancel(ID+1); AlarmReceiver.cancel(c); }
    @Override public synchronized boolean onStartJob(JobParameters params) {
        if(executor!=null && !executor.isShutdown()) return false;
        stopped=false; runningId=params.getJobId(); executor=Executors.newSingleThreadExecutor();
        ExecutorService currentExecutor=executor;
        executor.execute(()-> {
            try { check(); }
            finally { if(!stopped) jobFinished(params,false); currentExecutor.shutdown(); }
        });
        return true;
    }
    private void check() {
        var p=prefs(this); Instant now=Instant.now();
        if(!p.getBoolean("enabled",false) || !Alerts.allowed(this)
            || !StoreClock.due(now,p.getInt("hour",8),p.getInt("minute",30),p.getString("notifiedDay",""))) return;
        try {
            JSONObject session;
            synchronized(LOCK) { session=new Vault(this).load(); }
            if(session==null) return;
            JSONArray list=ShopApi.fetch(session);
            if(list.length()!=4) throw new java.io.IOException("每日商店返回数量异常，未发送提醒");
            synchronized(LOCK) {
                if(stopped || !p.getBoolean("enabled",false)) return;
                JSONObject current=new Vault(this).load();
                if(current==null || !current.toString().equals(session.toString())) return;
                p.edit().putString("cache",list.toString()).putLong("cacheAt",System.currentTimeMillis()).putString("status","后台查询成功").apply();
                if(!StoreClock.day(now).equals(p.getString("notifiedDay","")) && Alerts.send(this,"萨摩耶开商店 · 今日皮肤",ShopText.lines(list),411)) p.edit().putString("notifiedDay",StoreClock.day(now)).apply();
            }
        } catch(ShopApi.LoginExpired expired) {
            synchronized(LOCK) {
                if(stopped || !p.getBoolean("enabled",false)) return;
                String expiredMessage=getPackageName().endsWith(".cookie")?"现有 Cookie 已失效，自动提醒已暂停；请重新导入，不会自动登录或续期":"登录已失效，自动提醒已暂停；重新扫码可能使官方掌瓦退出";
                p.edit().putBoolean("enabled",false).putString("status",expiredMessage).apply();
                cancel(this);
                String today=StoreClock.day(now);
                if(!today.equals(p.getString("expiredDay","")) && Alerts.send(this,"萨摩耶开商店 · 提醒已暂停",expiredMessage,412)) p.edit().putString("expiredDay",today).apply();
            }
        } catch(Exception error) {
            if(!stopped) p.edit().putString("status","后台查询未成功，将在后续任务重试").apply();
        }
    }
    @Override public synchronized boolean onStopJob(JobParameters params) { if(params.getJobId()==runningId) { stopped=true; if(executor!=null) executor.shutdownNow(); } return true; }
}
