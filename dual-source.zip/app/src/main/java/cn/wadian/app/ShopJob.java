package cn.wadian.app;

import android.app.job.*;
import android.content.*;
import org.json.*;
import java.time.Instant;
import java.util.concurrent.*;

public final class ShopJob extends JobService {
    public static final Object LOCK=new Object();
    public static final int ID=410;
    private ExecutorService executor;
    private volatile boolean stopped;
    private int runningId=-1;
    public static android.content.SharedPreferences prefs(Context c) { return c.getSharedPreferences("settings",MODE_PRIVATE); }
    public static boolean schedule(Context c) {
        if(!prefs(c).getBoolean("enabled",false)) return false;
        JobInfo job=new JobInfo.Builder(ID,new ComponentName(c,ShopJob.class))
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPeriodic(15*60*1000L)
            .setPersisted(true).build();
        boolean ok=c.getSystemService(JobScheduler.class).schedule(job)==JobScheduler.RESULT_SUCCESS;
        AlarmReceiver.schedule(c);
        return ok;
    }
    public static void cancel(Context c) { c.getSystemService(JobScheduler.class).cancel(ID); c.getSystemService(JobScheduler.class).cancel(ID+1); AlarmReceiver.cancel(c); GuardService.stop(c); }
    @Override public synchronized boolean onStartJob(JobParameters params) {
        if(executor!=null && !executor.isShutdown()) return false;
        stopped=false; runningId=params.getJobId(); executor=Executors.newSingleThreadExecutor();
        ExecutorService currentExecutor=executor;
        executor.execute(()-> {
            try { check(); }
            finally { if(!stopped) jobFinished(params,false); currentExecutor.shutdown(); }
        });
        return true;
    }
    private void check() { StoreRunner.run(this,()->stopped); }
    @Override public synchronized boolean onStopJob(JobParameters params) { if(params.getJobId()==runningId) { stopped=true; if(executor!=null) executor.shutdownNow(); } return true; }
}
