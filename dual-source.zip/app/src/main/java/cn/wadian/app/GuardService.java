package cn.wadian.app;

import android.app.*;
import android.content.*;
import android.os.*;
import java.time.Instant;
import java.util.Locale;
import java.util.concurrent.*;

/** User-visible local reminder clock. Never starts an Activity or holds a screen wake lock. */
public final class GuardService extends Service {
    private static final String STOP="cn.wadian.app.STOP_GUARD";
    private static final String CHANNEL="reminder-clock-v1";
    private final ScheduledExecutorService executor=Executors.newSingleThreadScheduledExecutor();
    private volatile boolean stopped;
    private boolean scheduled;
    private boolean receiverRegistered;
    private final BroadcastReceiver recovery=new BroadcastReceiver() {
        @Override public void onReceive(Context c,Intent event) {
            if(stopped || !ShopJob.prefs(c).getBoolean("enabled",false)) return;
            ShopJob.prefs(c).edit().putLong("recoveryEventAt",System.currentTimeMillis()).putString("recoveryEvent",event.getAction()).apply();
            AlarmReceiver.schedule(c);
            try { executor.execute(GuardService.this::tick); } catch(RejectedExecutionException ignored) {}
        }
    };
    public static boolean start(Context c,String reason) {
        if(!ShopJob.prefs(c).getBoolean("enabled",false)) return false;
        ShopJob.prefs(c).edit().putString("guardRequestedBy",reason).apply();
        try { c.startForegroundService(new Intent(c,GuardService.class)); return true; }
        catch(RuntimeException e) {
            ShopJob.prefs(c).edit().putString("guardStatus","系统拒绝启动后台守候，等待闹钟或系统任务").apply(); return false;
        }
    }
    public static void stop(Context c) { c.stopService(new Intent(c,GuardService.class)); }
    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onCreate() {
        super.onCreate(); var p=ShopJob.prefs(this);
        p.edit().putLong("guardPreviousHeartbeat",p.getLong("guardHeartbeat",0)).putLong("guardStartedAt",System.currentTimeMillis()).apply();
        IntentFilter filter=new IntentFilter(Intent.ACTION_USER_UNLOCKED);
        filter.addAction(Intent.ACTION_USER_PRESENT);
        filter.addAction(android.net.ConnectivityManager.CONNECTIVITY_ACTION);
        try {
            if(Build.VERSION.SDK_INT>=33) registerReceiver(recovery,filter,Context.RECEIVER_NOT_EXPORTED);
            else registerReceiver(recovery,filter);
            receiverRegistered=true;
        } catch(RuntimeException e) { p.edit().putString("guardRecoveryStatus","系统未允许注册恢复事件，保留定时守候").apply(); }
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        if(intent!=null && STOP.equals(intent.getAction())) {
            ShopJob.prefs(this).edit().putBoolean("enabled",false).putString("status","已从状态通知关闭自动提醒").apply();
            ShopJob.cancel(this); stopSelf(); return START_NOT_STICKY;
        }
        if(!ShopJob.prefs(this).getBoolean("enabled",false)) { stopSelf(); return START_NOT_STICKY; }
        try { startForeground(415,notification()); }
        catch(RuntimeException e) {
            ShopJob.prefs(this).edit().putString("guardStatus","后台守候服务未获系统允许").apply(); stopSelf(); return START_NOT_STICKY;
        }
        ShopJob.prefs(this).edit().putString("guardStatus","后台守候已启动；不打开界面").apply();
        if(!scheduled) { scheduled=true; executor.scheduleWithFixedDelay(this::tick,0,15,TimeUnit.SECONDS); }
        return START_STICKY;
    }
    private Notification notification() {
        var p=ShopJob.prefs(this); NotificationManager manager=getSystemService(NotificationManager.class);
        NotificationChannel channel=new NotificationChannel(CHANNEL,"后台守候状态",NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("自动提醒开启时显示静默运行状态，可直接关闭守候"); channel.setShowBadge(false);
        manager.createNotificationChannel(channel);
        PendingIntent open=PendingIntent.getActivity(this,415,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop=PendingIntent.getService(this,416,new Intent(this,GuardService.class).setAction(STOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this,CHANNEL).setSmallIcon(R.drawable.ic_shop).setContentTitle("萨摩耶正在后台守候")
            .setContentText(String.format(Locale.ROOT,"每天 %02d:%02d 检查商店 · 无需打开应用",p.getInt("hour",8),p.getInt("minute",30)))
            .setContentIntent(open).addAction(new Notification.Action.Builder(R.drawable.ic_shop,"关闭自动提醒",stop).build())
            .setOngoing(true).setOnlyAlertOnce(true).setShowWhen(false).setCategory(Notification.CATEGORY_SERVICE).build();
    }
    private void tick() {
        if(stopped) return;
        var p=ShopJob.prefs(this); long now=System.currentTimeMillis();
        if(!p.getBoolean("enabled",false)) { stopSelf(); return; }
        long previous=p.getLong("guardHeartbeat",0);
        var edit=p.edit().putLong("guardHeartbeat",now);
        if(previous>0 && now-previous>90000) edit.putLong("guardGapSeconds",(now-previous)/1000);
        edit.apply();
        if(StoreClock.pendingDay(Instant.ofEpochMilli(now),p.getInt("hour",8),p.getInt("minute",30),p.getString("notifiedDay",""),p.getLong("catchupAt",0))==null) return;
        if(now-p.getLong("guardAttemptAt",0)<60000) return;
        p.edit().putLong("guardAttemptAt",now).putString("dispatchStatus","后台守候检测到待执行提醒").apply();
        PowerManager.WakeLock wake=getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,getPackageName()+":guard-query");
        try { wake.acquire(60000); StoreRunner.run(this,()->stopped); }
        catch(RuntimeException e) { p.edit().putString("guardStatus","守候查询未执行成功，稍后重试").apply(); }
        finally { if(wake.isHeld()) wake.release(); }
    }
    @Override public void onTaskRemoved(Intent intent) {
        if(ShopJob.prefs(this).getBoolean("enabled",false)) AlarmReceiver.schedule(this);
        super.onTaskRemoved(intent);
    }
    @Override public void onDestroy() {
        stopped=true; executor.shutdownNow();
        if(receiverRegistered) unregisterReceiver(recovery);
        ShopJob.prefs(this).edit().putLong("guardStoppedAt",System.currentTimeMillis()).putString("guardStatus","守候服务已停止；如非主动关闭，可能被系统回收").apply();
        super.onDestroy();
    }
}
