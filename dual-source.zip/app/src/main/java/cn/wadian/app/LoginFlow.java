package cn.wadian.app;

import org.json.*;
import android.util.Base64;
import java.io.IOException;
import java.util.*;
import java.util.regex.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/** Protocol implementation; credentials come only from the user's explicit scan/confirmation. */
public final class LoginFlow {
    public interface Display { void qr(byte[] png, String message); void status(String message); }
    private final Net net = new Net();
    private final Display display;
    public LoginFlow(Display display) { this.display = display; }
    private static void pause() throws InterruptedException { Thread.sleep(2000); }
    static String match(String input, String pattern) {
        Matcher m = Pattern.compile(pattern).matcher(input); return m.find() ? m.group(1) : "";
    }
    public JSONObject wechat() throws Exception {
        String app = "wxcbb49f1f39656c2a";
        JSONObject ticket = net.post(ShopApi.ROOT+"auth/get_sdk_ticket", ShopApi.envelope().put("sdk_appid", app).put("mcode","69028af6dca2c107f4f58290100011b1a303"), null);
        JSONObject data = ticket.optJSONObject("data");
        String value = data == null ? "" : data.optString("ticket");
        if (value.isEmpty()) throw new IOException("微信授权服务暂不可用，请重试");
        String nonce = UUID.randomUUID().toString().replace("-", "").substring(0, 12);
        String time = Long.toString(System.currentTimeMillis()/1000);
        byte[] digest = MessageDigest.getInstance("SHA-1").digest(("appid="+app+"&noncestr="+nonce+"&sdk_ticket="+value+"&timestamp="+time).getBytes(StandardCharsets.UTF_8));
        StringBuilder hex = new StringBuilder(); for (byte b : digest) hex.append(String.format(Locale.ROOT, "%02x", b & 255));
        JSONObject qr = new JSONObject(net.text(Net.query("https://open.weixin.qq.com/connect/sdk/qrconnect?f=json",
                Net.fields("appid",app,"noncestr",nonce,"timestamp",time,"scope","snsapi_userinfo","signature",hex.toString()))));
        if (qr.optInt("errcode", -1) != 0) throw new IOException("微信二维码生成失败，请重试");
        String image = qr.getJSONObject("qrcode").getString("qrcodebase64");
        display.qr(Base64.decode(image.substring(image.indexOf(',')+1), Base64.DEFAULT), "请使用微信扫码并确认登录。可保存二维码后尝试从相册识别。");
        long deadline = System.nanoTime()/1000000+180000;
        String last = "";
        while (System.nanoTime()/1000000 < deadline) {
            pause();
            String raw = net.text("https://long.open.weixin.qq.com/connect/l/qrconnect?f=json&uuid="+Net.enc(qr.getString("uuid"))+(last.isEmpty()?"":"&last="+last));
            String code;
            try {
                JSONObject state = new JSONObject(raw); last = state.optString("wx_errcode"); code = state.optString("wx_code");
            } catch (JSONException e) { last = match(raw,"wx_errcode\\s*=\\s*(\\d+)"); code = match(raw,"wx_code\\s*=\\s*['\"]([^'\"]+)['\"]"); }
            if (!code.isEmpty() && (last.equals("405") || last.equals("0"))) {
                display.status("正在完成微信登录…");
                return ShopApi.login(net, "wechat", new JSONObject().put("appid",app).put("check_third_type",1).put("code",code).put("wx_info_type",1));
            }
            if (last.equals("404")) display.status("已扫描，请在微信中确认");
            else if (!last.equals("408") && !last.equals("0")) throw new IOException("微信二维码已过期或授权已取消，请重试");
        }
        throw new IOException("二维码已过期，请重新生成");
    }
    public JSONObject qq() throws Exception {
        display.status("正在从 QQ 获取本次授权上下文…");
        long sdkTime=System.currentTimeMillis()/1000;
        String authorize=Net.query("https://openmobile.qq.com/oauth2.0/m_authorize",Net.fields(
                "cancel_display","1","sdkp","a","display","mobile","format","json","sdkv","3.5.17.lite",
                "response_type","token","status_os","12","client_id","102061775","switch","1",
                "status_version","30","show_download_ui","true","pf","openmobile_android","scope","all",
                "compat_v","1","style","qr","redirect_uri","auth://tauth.qq.com/",
                "sign",QqProtocol.sdkSign(sdkTime),"time",Long.toString(sdkTime),"status_machine","Android"));
        String loginUrl=QqProtocol.loginUrl(net.text(authorize));
        Map<String,String> context=QqProtocol.params(loginUrl);
        String callback=context.getOrDefault("s_url","http://connect.qq.com");
        net.referer(authorize);
        String page=net.text(loginUrl);
        String version=match(page,"/monorepo/([0-9A-Za-z]+)/ptlogin/js/");
        String loginSig=net.cookie("pt_login_sig");
        if(loginSig.isEmpty()) loginSig=match(page,"g_login_sig\\s*=\\s*encodeURIComponent\\(\"([^\"]+)\"\\)");
        if(loginSig.isEmpty()) throw new IOException("QQ 授权页未建立登录签名，请重新生成二维码（初始化阶段）");
        net.referer(loginUrl);
        byte[] png=net.get(Net.query("https://xui.ptlogin2.qq.com/ssl/ptqrshow",Net.fields(
                "appid","716027609","pt_3rd_aid","102061775","daid","381","s","8","e","0","type","0",
                "u1",callback,"t",Double.toString(Math.random()))));
        String sig=net.cookie("qrsig");
        if(sig.isEmpty()) throw new IOException("QQ 授权会话未建立，请重试");
        int token=0; for(char c:sig.toCharArray()) token+=(token<<5)+c;
        Map<String,String> poll=Net.fields("u1",callback,"from_ui","1","type","1","ptlang","2052",
                "ptqrtoken",Integer.toString(token&0x7fffffff),"daid","381","aid","716027609","pt_3rd_aid","102061775",
                "device","2","ptopt","1","pt_uistyle",context.getOrDefault("style","35"),"login_sig",loginSig,
                "pt_openlogin_data",QqProtocol.openData(context,net.cookie("idt"),System.currentTimeMillis()));
        if(!version.isEmpty()) poll.put("jsver",version);
        String aegis=net.cookie("__aegis_uid");
        if(!aegis.isEmpty()) poll.put("aegis_uid",aegis);
        display.qr(png,"请用 QQ 扫码并确认。最多等待 5 分钟，QQ 服务端可能提前使二维码失效。");
        long deadline=System.nanoTime()/1000000+300000;
        int temporaryErrors=0;
        while(System.nanoTime()/1000000<deadline) {
            pause(); poll.put("r",Double.toString(Math.random()));
            QqProtocol.State state=QqProtocol.state(net.text(Net.query("https://xui.ptlogin2.qq.com/ssl/ptqrlogin",poll)));
            String code=state.code;
            if(code.equals("0")) {
                if(state.url.isEmpty()) throw new IOException("QQ 已确认，但未返回授权回调地址");
                display.status("QQ 已确认，正在取得授权回调…");
                Map<String,String> params=resolve(state.url);
                String openid=params.getOrDefault("openid",""),access=params.getOrDefault("access_token","");
                if(openid.isEmpty()||access.isEmpty()) throw new IOException("QQ 已确认，但未取得登录凭证（回调阶段）");
                display.status("正在登录掌瓦服务…");
                net.referer("https://openmobile.qq.com/");
                return ShopApi.login(net,"qq",new JSONObject().put("appid",102061775).put("openid",openid).put("sig",access).put("qq_info_type",5).put("uin",0));
            }
            if(code.equals("65")) throw new IOException("QQ 服务端提示二维码已失效，请重新生成；不是本地等待超时");
            int remaining=(int)Math.max(0,(deadline-System.nanoTime()/1000000)/1000);
            String countdown=String.format(Locale.ROOT,"（剩余 %02d:%02d）",remaining/60,remaining%60);
            if(code.equals("-1")) {
                temporaryErrors++;
                if(temporaryErrors<=5) { display.status("QQ 暂未完成授权，保留会话重试 "+temporaryErrors+"/5…"+countdown); continue; }
                throw new IOException("QQ 授权服务持续返回 -1："+state.safeMessage()+"。已保留会话重试，未将错误当作登录成功。");
            }
            temporaryErrors=0;
            if(code.equals("67")) display.status("已扫描，请在 QQ 中确认"+countdown);
            else if(code.equals("66")) display.status("等待 QQ 扫码确认…"+countdown);
            else throw new IOException("QQ 授权未完成（"+code+"）："+state.safeMessage());
        }
        throw new IOException("本地等待 5 分钟已结束，请重新生成二维码");
    }
    private Map<String,String> resolve(String address) throws Exception {
        Map<String,String> all = new HashMap<>(); Set<String> seen = new HashSet<>();
        for (int i=0; i<8 && seen.add(address); i++) {
            all.putAll(QqProtocol.credentials(address));
            if (all.containsKey("openid") && all.containsKey("access_token")) return all;
            String key = all.getOrDefault("keystr",all.getOrDefault("redirect_uri_key",all.getOrDefault("key",net.cookie("keystr"))));
            if (!key.isEmpty()) {
                String response = net.text("https://openmobile.qq.com/oauth2.0/m_get_redirect_url?keystr="+Net.enc(key));
                String callback = match(response.replace("\\/","/"),"(auth://tauth\\.qq\\.com/[^\\s\"'<>]+)");
                if (!callback.isEmpty()) { address=callback; continue; }
            }
            if (!address.startsWith("https://")) break;
            String next=net.text(address);
            if (next.startsWith("https://") || next.startsWith("auth://")) { address=next; continue; }
            String extracted=match(next.replace("\\/","/"),"(?:url|location\\.href)\\s*[:=]\\s*['\"]([^'\"]+)['\"]");
            if (extracted.isEmpty()) break; address=extracted;
        }
        return all;
    }
}
