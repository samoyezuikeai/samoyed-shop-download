package cn.wadian.app;

import java.time.*;

/** Follow the phone's current timezone, including changes while the app is installed. */
public final class StoreClock {
    public static ZoneId zone() { return ZoneId.systemDefault(); }
    public static String day(Instant now) { return now.atZone(zone()).toLocalDate().toString(); }
    public static String slot(Instant now,int hour,int minute) { return day(now)+"@"+hour+":"+minute; }
    public static boolean due(Instant now, int hour, int minute, String notifiedDay) {
        ZonedDateTime local = now.atZone(zone());
        return !day(now).equals(notifiedDay) && !local.toLocalTime().isBefore(LocalTime.of(hour, minute));
    }
    public static long nextAlarm(Instant now,int hour,int minute) {
        ZonedDateTime local=now.atZone(zone());
        ZonedDateTime next=local.toLocalDate().atTime(hour,minute).atZone(zone());
        if(!next.toInstant().isAfter(now)) next=local.toLocalDate().plusDays(1).atTime(hour,minute).atZone(zone());
        return next.toInstant().toEpochMilli();
    }
    private StoreClock() {}
}
