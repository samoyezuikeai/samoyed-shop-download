package cn.wadian.app;

import android.content.Context;
import org.json.*;
import java.time.Instant;
import java.util.function.BooleanSupplier;

/** One common execution path for alarm services and periodic catch-up jobs. */
public final class StoreRunner {
    private static final Object RUN_LOCK=new Object();
    public static void run(Context c,BooleanSupplier stopped) {
        synchronized(RUN_LOCK) { check(c,stopped); }
    }
    private static void check(Context c,BooleanSupplier stopped) {
        var p=ShopJob.prefs(c); Instant now=Instant.now();
        p.edit().putLong("workerAt",System.currentTimeMillis()).apply();
        if(stopped.getAsBoolean() || !p.getBoolean("enabled",false)) return;
        if(!Alerts.allowed(c)) { p.edit().putString("status","任务已执行，但通知权限未允许").apply(); return; }
        int hour=p.getInt("hour",8),minute=p.getInt("minute",30);
        String slot=StoreClock.slot(now,hour,minute);
        if(!StoreClock.due(now,hour,minute,p.getString("notifiedDay",""))) {
            p.edit().putString("dispatchStatus",StoreClock.day(now).equals(p.getString("notifiedDay",""))?"本时段今天已自动提醒；手动查询不参与去重":"后台任务已运行，尚未到设定时间").apply(); return;
        }
        try {
            JSONObject session;
            synchronized(ShopJob.LOCK) { session=new Vault(c).load(); }
            if(session==null) { p.edit().putString("status","后台任务已执行，但没有可用凭证").apply(); return; }
            p.edit().putString("status","后台正在请求今日商店").apply();
            JSONArray list=ShopApi.fetch(session);
            if(list.length()!=4) throw new java.io.IOException("每日商店数量异常");
            synchronized(ShopJob.LOCK) {
                if(stopped.getAsBoolean() || !p.getBoolean("enabled",false)) return;
                if(!slot.equals(StoreClock.slot(Instant.now(),p.getInt("hour",8),p.getInt("minute",30)))) return;
                JSONObject current=new Vault(c).load();
                if(current==null || !current.toString().equals(session.toString())) return;
                p.edit().putString("cache",list.toString()).putLong("cacheAt",System.currentTimeMillis()).apply();
                if(!StoreClock.day(now).equals(p.getString("notifiedDay","")) && Alerts.send(c,"萨摩耶开商店 · 今日皮肤",ShopText.lines(list),411)) {
                    p.edit().putString("notifiedDay",StoreClock.day(now)).putLong("automaticNoticeAt",System.currentTimeMillis()).putString("status","后台查询成功，已提交皮肤通知").putString("dispatchStatus","本时段提醒完成").apply();
                } else p.edit().putString("status","商店查询成功，但通知未提交或已提醒").apply();
            }
        } catch(ShopApi.LoginExpired expired) {
            synchronized(ShopJob.LOCK) {
                if(stopped.getAsBoolean() || !p.getBoolean("enabled",false)) return;
                String message=c.getPackageName().endsWith(".cookie")?"Cookie 已失效，自动提醒暂停；请重新导入":"登录已失效，自动提醒暂停；重新扫码可能挤掉官方掌瓦";
                p.edit().putBoolean("enabled",false).putString("status",message).apply(); ShopJob.cancel(c);
                Alerts.send(c,"萨摩耶开商店 · 提醒已暂停",message,412);
            }
        } catch(Exception e) {
            if(!stopped.getAsBoolean()) p.edit().putString("status","后台已执行但查询失败，将由后续任务补查").apply();
        }
    }
}
