package cn.wadian.app;

import org.json.*;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Isolated, in-memory cookie jar for each login. No global cookie manager or HTTP logging. */
public final class Net {
    public static final String UA = "mval/2.6.0.10062 Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/110.0.5481.154 Mobile Safari/537.36";
    private final SessionCookies cookies = new SessionCookies();
    private String referer="https://openmobile.qq.com/";
    public void referer(String value) { referer=value; }
    public static String enc(String value) { try { return java.net.URLEncoder.encode(value, "UTF-8"); } catch(java.io.UnsupportedEncodingException impossible) { throw new AssertionError(impossible); } }
    public static String dec(String value) { try { return java.net.URLDecoder.decode(value, "UTF-8"); } catch(java.io.UnsupportedEncodingException impossible) { throw new AssertionError(impossible); } }
    public static Map<String,String> fields(String... pairs) {
        Map<String,String> result=new LinkedHashMap<>(); for(int i=0;i<pairs.length;i+=2) result.put(pairs[i],pairs[i+1]); return result;
    }
    public static String query(String url, Map<String,String> fields) {
        StringJoiner joiner = new StringJoiner("&"); fields.forEach((k,v) -> joiner.add(enc(k)+"="+enc(v)));
        return url + (url.contains("?") ? "&" : "?") + joiner;
    }
    public byte[] get(String url) throws Exception { return request(url, null, null); }
    public String text(String url) throws Exception { return new String(get(url), StandardCharsets.UTF_8); }
    public JSONObject post(String url, JSONObject body, String cookie) throws Exception {
        return new JSONObject(new String(request(url, body, cookie), StandardCharsets.UTF_8));
    }
    public String cookie(String name) {
        return cookies.value(name);
    }
    public byte[] request(String address, JSONObject body, String explicitCookie) throws Exception {
        URI uri = URI.create(address);
        // Only Tencent/Riot game identity and app services; reject unexpected redirect destinations.
        String host = uri.getHost();
        if (!"https".equalsIgnoreCase(uri.getScheme()) || host == null || !(host.equals("qq.com") || host.endsWith(".qq.com") || host.endsWith(".weixin.qq.com")))
            throw new IOException("登录服务返回了不支持的地址");
        HttpURLConnection connection = (HttpURLConnection)uri.toURL().openConnection();
        connection.setInstanceFollowRedirects(false);
        connection.setConnectTimeout(15000); connection.setReadTimeout(20000);
        connection.setRequestProperty("User-Agent", UA);
        connection.setRequestProperty("Referer", referer);
        connection.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9");
        String cookieHeader=cookies.header(uri);
        if(!cookieHeader.isEmpty()) connection.setRequestProperty("Cookie",cookieHeader);
        if (explicitCookie != null) connection.setRequestProperty("Cookie", explicitCookie);
        try {
            if (body != null) {
                connection.setRequestMethod("POST"); connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type", "application/json");
                try (OutputStream out = connection.getOutputStream()) { out.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
            }
            int status = connection.getResponseCode(); cookies.receive(uri, connection.getHeaderFields());
            if (status >= 300 && status < 400) {
                String location = connection.getHeaderField("Location");
                if (location == null) throw new IOException("登录跳转缺少地址");
                return uri.resolve(location).toString().getBytes(StandardCharsets.UTF_8);
            }
            if (status < 200 || status >= 300) throw new IOException("服务请求失败（HTTP " + status + "）");
            try (InputStream in = connection.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] chunk = new byte[8192]; int n;
                while ((n = in.read(chunk)) >= 0) {
                    if (out.size() + n > 12 * 1024 * 1024) throw new IOException("响应内容过大");
                    out.write(chunk, 0, n);
                }
                return out.toByteArray();
            }
        } finally { connection.disconnect(); }
    }
}
