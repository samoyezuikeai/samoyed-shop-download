package cn.wadian.app;

import java.net.HttpCookie;
import java.net.URI;
import java.util.*;

/** RFC 6265 domain/path matching, including Domain=example.com without a leading dot. */
final class SessionCookies {
    private static final class Stored {
        final HttpCookie cookie;
        final String domain,path;
        final boolean hostOnly;
        Stored(HttpCookie cookie,String domain,String path,boolean hostOnly) {
            this.cookie=cookie; this.domain=domain; this.path=path; this.hostOnly=hostOnly;
        }
    }
    private final Map<String,Stored> entries=new LinkedHashMap<>();
    private static boolean matches(String host,String domain) { return host.equals(domain) || host.endsWith("."+domain); }
    synchronized void receive(URI origin,Map<String,List<String>> headers) {
        String host=origin.getHost().toLowerCase(Locale.ROOT);
        for(var field:headers.entrySet()) {
            if(field.getKey()==null || !(field.getKey().equalsIgnoreCase("Set-Cookie") || field.getKey().equalsIgnoreCase("Set-Cookie2"))) continue;
            for(String line:field.getValue()) {
                List<HttpCookie> parsed;
                try { parsed=HttpCookie.parse(line); } catch(IllegalArgumentException e) { continue; }
                for(HttpCookie c:parsed) {
                    boolean hostOnly=c.getDomain()==null || c.getDomain().isEmpty();
                    String domain=hostOnly?host:c.getDomain().toLowerCase(Locale.ROOT).replaceFirst("^\\.","");
                    // All connections are Tencent endpoints. Never accept public-suffix or foreign cookies.
                    if(!matches(host,domain) || !(domain.equals("qq.com") || domain.endsWith(".qq.com"))) continue;
                    String path=c.getPath();
                    if(path==null || !path.startsWith("/")) {
                        String requestPath=origin.getPath(); int end=requestPath.lastIndexOf('/');
                        path=end<=0?"/":requestPath.substring(0,end);
                    }
                    String key=c.getName()+"\n"+domain+"\n"+path;
                    if(c.getMaxAge()==0 || c.hasExpired()) entries.remove(key);
                    else entries.put(key,new Stored(c,domain,path,hostOnly));
                }
            }
        }
    }
    synchronized String header(URI destination) {
        entries.values().removeIf(s->s.cookie.hasExpired());
        String host=destination.getHost().toLowerCase(Locale.ROOT);
        String path=destination.getPath(); if(path==null || path.isEmpty()) path="/";
        List<Stored> eligible=new ArrayList<>();
        for(Stored s:entries.values()) {
            if(s.hostOnly?!host.equals(s.domain):!matches(host,s.domain)) continue;
            if(s.cookie.getSecure() && !destination.getScheme().equalsIgnoreCase("https")) continue;
            if(!(path.equals(s.path) || (path.startsWith(s.path) && (s.path.endsWith("/") || path.charAt(s.path.length())=='/')))) continue;
            eligible.add(s);
        }
        eligible.sort((a,b)->Integer.compare(b.path.length(),a.path.length()));
        StringJoiner result=new StringJoiner("; ");
        for(Stored s:eligible) result.add(s.cookie.getName()+"="+s.cookie.getValue());
        return result.toString();
    }
    synchronized String value(String name) {
        String result="";
        for(Stored s:entries.values()) if(s.cookie.getName().equals(name) && !s.cookie.hasExpired()) result=s.cookie.getValue();
        return result;
    }
}
