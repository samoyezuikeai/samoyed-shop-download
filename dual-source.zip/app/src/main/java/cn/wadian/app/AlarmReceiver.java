package cn.wadian.app;

import android.app.*;
import android.app.job.*;
import android.content.*;
import android.os.Build;
import java.time.Instant;

public final class AlarmReceiver extends BroadcastReceiver {
    private static final String ACTION="cn.wadian.app.DAILY_ALARM";
    private static PendingIntent intent(Context c) {
        return PendingIntent.getBroadcast(c,430,new Intent(c,AlarmReceiver.class).setAction(ACTION),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    public static boolean exactAllowed(Context c) {
        return Build.VERSION.SDK_INT<31 || c.getSystemService(AlarmManager.class).canScheduleExactAlarms();
    }
    public static void schedule(Context c) {
        var p=ShopJob.prefs(c); if(!p.getBoolean("enabled",false)) { cancel(c); return; }
        long at=StoreClock.nextAlarm(Instant.now(),p.getInt("hour",8),p.getInt("minute",30));
        AlarmManager manager=c.getSystemService(AlarmManager.class);
        try {
            boolean exact=exactAllowed(c);
            if(exact) manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,intent(c));
            else manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,intent(c));
            p.edit().putLong("alarmAt",at).putString("alarmMode",exact?"精确闹钟":"普通闹钟（可能延迟）").putBoolean("alarmExact",exact).apply();
        } catch(SecurityException e) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,intent(c));
            p.edit().putLong("alarmAt",at).putString("alarmMode","普通闹钟（精确授权不可用）").putBoolean("alarmExact",false).apply();
        } catch(RuntimeException e) { p.edit().putString("status","系统未接受闹钟，请检查卓易通后台设置").putLong("alarmAt",0).apply(); }
    }
    public static void cancel(Context c) { c.getSystemService(AlarmManager.class).cancel(intent(c)); }
    @Override public void onReceive(Context c,Intent event) {
        if(!ShopJob.prefs(c).getBoolean("enabled",false)) return;
        boolean alarm=ACTION.equals(event.getAction());
        boolean exact=ShopJob.prefs(c).getBoolean("alarmExact",false);
        if(alarm) ShopJob.prefs(c).edit().putLong("alarmReceived",System.currentTimeMillis()).putString("status","闹钟已触发，等待执行查询").apply();
        schedule(c);
        if(alarm && exact) {
            try { c.startForegroundService(new Intent(c,ShopRunService.class)); return; }
            catch(RuntimeException e) { ShopJob.prefs(c).edit().putString("status","系统拒绝即时查询服务，转为后台任务").apply(); }
        }
        // Network execution belongs to a JobService rather than a short-lived broadcast.
        JobInfo job=new JobInfo.Builder(ShopJob.ID+1,new ComponentName(c,ShopJob.class))
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setMinimumLatency(0).setOverrideDeadline(0).build();
        int accepted=c.getSystemService(JobScheduler.class).schedule(job);
        ShopJob.prefs(c).edit().putString("dispatchStatus",accepted==JobScheduler.RESULT_SUCCESS?"后台任务已提交，等待系统执行":"后台任务被系统拒绝").apply();
    }
}
