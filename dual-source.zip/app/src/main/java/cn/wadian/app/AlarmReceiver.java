package cn.wadian.app;

import android.app.*;
import android.app.job.*;
import android.content.*;
import android.os.Build;
import java.time.Instant;

public final class AlarmReceiver extends BroadcastReceiver {
    private static final String ACTION="cn.wadian.app.DAILY_ALARM";
    private static PendingIntent intent(Context c) {
        return PendingIntent.getBroadcast(c,430,new Intent(c,AlarmReceiver.class).setAction(ACTION),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    public static boolean exactAllowed(Context c) {
        return Build.VERSION.SDK_INT<31 || c.getSystemService(AlarmManager.class).canScheduleExactAlarms();
    }
    public static void schedule(Context c) {
        var p=ShopJob.prefs(c); if(!p.getBoolean("enabled",false)) { cancel(c); return; }
        long at=StoreClock.nextAlarm(Instant.now(),p.getInt("hour",8),p.getInt("minute",30));
        AlarmManager manager=c.getSystemService(AlarmManager.class);
        try {
            if(exactAllowed(c)) manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,intent(c));
            else manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,intent(c));
        } catch(SecurityException e) { manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,intent(c)); }
    }
    public static void cancel(Context c) { c.getSystemService(AlarmManager.class).cancel(intent(c)); }
    @Override public void onReceive(Context c,Intent event) {
        if(!ShopJob.prefs(c).getBoolean("enabled",false)) return;
        schedule(c);
        // Network execution belongs to a JobService rather than a short-lived broadcast.
        JobInfo job=new JobInfo.Builder(ShopJob.ID+1,new ComponentName(c,ShopJob.class))
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setMinimumLatency(0).setOverrideDeadline(0).build();
        c.getSystemService(JobScheduler.class).schedule(job);
    }
}
