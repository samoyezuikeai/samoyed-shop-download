package cn.wadian.app;

import java.io.IOException;
import java.util.*;
import org.json.JSONObject;

/** Imports only an explicit Cookie request header. No login or ticket refresh. */
public final class ImportedCookie {
    private static final Set<String> ALLOWED = new HashSet<>(Arrays.asList(
        "clientType", "userId", "tid", "accountType", "openid", "uin", "appid",
        "acctype", "access_token", "skey", "mainAccountType", "exchangeType"));
    public static JSONObject parse(String input) throws Exception {
        if(input==null || input.length()>32768) throw new IOException("Cookie 为空或长度超限");
        String value=input.trim();
        if(value.regionMatches(true,0,"Cookie:",0,7)) value=value.substring(7).trim();
        if(value.isEmpty() || value.indexOf('\r')>=0 || value.indexOf('\n')>=0)
            throw new IOException("请只粘贴一行 Cookie 请求头，不要粘贴完整抓包、响应头或命令");
        LinkedHashMap<String,String> parts=new LinkedHashMap<>();
        for(String field:value.split(";")) {
            field=field.trim(); if(field.isEmpty()) continue;
            int equals=field.indexOf('=');
            if(equals<=0) throw new IOException("Cookie 格式不正确，应为 名称=值; 名称=值");
            String name=field.substring(0,equals).trim(), content=field.substring(equals+1).trim();
            if(!ALLOWED.contains(name)) continue;
            ShopApi.safe(content);
            if(parts.containsKey(name)) throw new IOException("Cookie 包含重复字段，请复制单个商店请求的 Cookie");
            parts.put(name,content);
        }
        if(parts.getOrDefault("userId","").isEmpty() || parts.getOrDefault("tid","").isEmpty())
            throw new IOException("需要官方掌瓦商店请求中的 userId 和 tid；不能用 QQ 登录 Cookie 代替");
        StringBuilder header=new StringBuilder();
        for(Map.Entry<String,String> part:parts.entrySet()) {
            if(header.length()>0) header.append("; ");
            header.append(part.getKey()).append('=').append(part.getValue());
        }
        return new JSONObject().put("mode","cookie").put("userId",parts.get("userId"))
            .put("tid",parts.get("tid")).put("cookieHeader",header.toString());
    }
}
